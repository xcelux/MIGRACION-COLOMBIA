package com.migracion.cdi.controller;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.migracion.cdi.common.CDIUtil;
import com.migracion.cdi.model.InvestigadoProceso;
import com.migracion.cdi.model.ProcesoDisciplinar;
import com.migracion.cdi.model.Subtipologia;
import com.migracion.cdi.model.TipoGeneral;
import com.migracion.cdi.model.Tipologia;
import com.migracion.cdi.service.IProcesoDisciplinarService;
import com.migracion.cdi.service.ISubtipologiaService;
import com.migracion.cdi.service.ITipoGeneralService;
import com.migracion.cdi.service.ITipologiaService;



@Controller
@RequestMapping(value="/proceso")
public class ProcesoDisciplinarController {	
	
	@Autowired
	private IProcesoDisciplinarService procesoDisciplinarService;
	
	@Autowired
	private ITipoGeneralService tipoGeneralService;
	
	@Autowired
	private ITipologiaService tipologiaService;
	
	@Autowired
	private ISubtipologiaService subtipologiaService;
	
	private CDIUtil cdiUtil = new CDIUtil();
	
	
	@GetMapping("/crear")
	public String mostrarHome(Model model) {
		
		
		List<TipoGeneral> nacionalidadesSelect = new LinkedList<TipoGeneral>();
		List<TipoGeneral> regionalesSelect = new LinkedList<TipoGeneral>();
		List<TipoGeneral> fuenteDatosSelect = new LinkedList<TipoGeneral>();
		List<TipoGeneral> tipoProcesoSelect = new LinkedList<TipoGeneral>();
		List<TipoGeneral> tipoQuejosoSelect = new LinkedList<TipoGeneral>();
		List<Tipologia> tipologiaSelect = new LinkedList<Tipologia>();
		List<Subtipologia> subtipologiaSelect = new LinkedList<Subtipologia>();
		List<InvestigadoProceso> listaFuncionariosSelect = new LinkedList<InvestigadoProceso>();
		
		ProcesoDisciplinar procesoDisciplinar = new ProcesoDisciplinar();
				
		try {
			
			nacionalidadesSelect = tipoGeneralService.consultaListaTiposGenerales("Nacionalidad");
			regionalesSelect = 	tipoGeneralService.consultaListaTiposGenerales("Regional");
			fuenteDatosSelect = tipoGeneralService.consultaListaTiposGenerales("FuenteDatos");
			tipoProcesoSelect = tipoGeneralService.consultaListaTiposGenerales("TipoProceso");
			tipoQuejosoSelect = tipoGeneralService.consultaListaTiposGenerales("TipoQuejoso");
			tipologiaSelect = tipologiaService.consultaListaTipologias();
			subtipologiaSelect = subtipologiaService.consultaListaSubtipologias();
			
			InvestigadoProceso investigadoProceso = new InvestigadoProceso();
			investigadoProceso.setIdInvestigado(1);
			investigadoProceso.setNombreInvestigado("ALEXANDER TRES PALACIOS");
			listaFuncionariosSelect.add(investigadoProceso);
			
			InvestigadoProceso investigadoProceso2 = new InvestigadoProceso();
			investigadoProceso2.setIdInvestigado(2);
			investigadoProceso2.setNombreInvestigado("ANDRÉS VILLA NUEVA");
			listaFuncionariosSelect.add(investigadoProceso2);
			
			InvestigadoProceso investigadoProceso3 = new InvestigadoProceso();
			investigadoProceso3.setIdInvestigado(3);
			investigadoProceso3.setNombreInvestigado("FELIPE SANTODOMINGO");
			listaFuncionariosSelect.add(investigadoProceso3);
			
			InvestigadoProceso investigadoProceso4 = new InvestigadoProceso();
			investigadoProceso4.setIdInvestigado(4);
			investigadoProceso4.setNombreInvestigado("PABLO LACOTURIE");
			listaFuncionariosSelect.add(investigadoProceso4);
			
			
			
			//linea de codigo creada exclusivamente para probar relacion entre tablas
			procesoDisciplinar = procesoDisciplinarService.consultaProcesoDisciplinarPorId(34);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		model.addAttribute("nacionalidadesSelect",nacionalidadesSelect);
		model.addAttribute("regionalesSelect",regionalesSelect);
		model.addAttribute("fuenteDatosSelect",fuenteDatosSelect);
		model.addAttribute("tipoProcesoSelect",tipoProcesoSelect);
		model.addAttribute("tipoQuejosoSelect",tipoQuejosoSelect);
		model.addAttribute("tipologiaSelect",tipologiaSelect);
		model.addAttribute("subtipologiaSelect",subtipologiaSelect);
		model.addAttribute("listaFuncionariosSelect",listaFuncionariosSelect);
		
		return "proceso/proceso";
	}
	
	
	@RequestMapping(value="/guardar", method = RequestMethod.POST)
	public String guardar(ProcesoDisciplinar procesoDisciplinar, BindingResult result, RedirectAttributes attributes, @RequestParam("investigados") String[] investigados) {
		
		if(result.hasErrors()) {
			
			for(ObjectError error: result.getAllErrors()) {
				System.out.println("Ocurrio un error: "+error.getDefaultMessage());
			}
			
			return "redirect:/proceso/crear";
		}
		
		//Estado de decision 14 en Evaluacion
		TipoGeneral estadoDecision = new TipoGeneral();
		TipoGeneral etapa = new TipoGeneral();
		
		try {
			
			estadoDecision = tipoGeneralService.buscarTipoGeneralesPorValor("Evaluacion");
			etapa = tipoGeneralService.buscarTipoGeneralesPorValor("Evaluar Noticia");
			String ultimoCodigoExpediente = procesoDisciplinarService.buscarUltimoCodigoExpediente();
			
			if(ultimoCodigoExpediente==null) {
				procesoDisciplinar.setNumeroExpediente("0001/"+cdiUtil.anioActual());
			}else {
				procesoDisciplinar.setNumeroExpediente(cdiUtil.generarCodidgoExpediente(ultimoCodigoExpediente));
			}
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		procesoDisciplinar.setEstado(1);
		procesoDisciplinar.setFechaElaboracionFormato(new Date());
		procesoDisciplinar.setIdRadicadoOrfeo("6251-1"); //Esperando servicio de Orfeo.
		procesoDisciplinar.setIdEstadoDecision(estadoDecision);
		procesoDisciplinar.setIdEtapaActual(etapa);
		
		InvestigadoProceso investigadoProceso = new InvestigadoProceso();
		investigadoProceso.setIdProcesoDisciplinar(2);
		investigadoProceso.setIdInvestigado(2);
		investigadoProceso.setNombreInvestigado("Andres Cortina");
		
		List<InvestigadoProceso> listaInvestigados = new ArrayList();
		listaInvestigados.add(investigadoProceso);
		
		procesoDisciplinar.setListaInvestigados(listaInvestigados);
		
		procesoDisciplinarService.guardar(procesoDisciplinar);
		
		attributes.addFlashAttribute("msg","Proceso Guardado Satisfactoriamente. --> Radicado Orfeo "+procesoDisciplinar.getIdRadicadoOrfeo());
		return "redirect:/proceso/crear";
		
	}
	
	
	@ResponseBody
	@GetMapping("/dependencias/{idRegional}")
	public List<TipoGeneral> buscarDependencias(@PathVariable("idRegional") Integer idRegional) throws Exception {
		System.out.println("Hola");
		List<TipoGeneral> dependenciasSelect = new LinkedList<TipoGeneral>();
		dependenciasSelect = tipoGeneralService.consultaListaTiposGenerales("Dependencia");
		return dependenciasSelect;
	}
	
	
	@InitBinder
	public void initBinder(WebDataBinder webDataBinder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		webDataBinder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat,false));
	}
	
	

}
