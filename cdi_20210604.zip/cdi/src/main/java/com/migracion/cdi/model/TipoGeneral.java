package com.migracion.cdi.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="TipoGeneral")
public class TipoGeneral implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TipoGeneral_idTipoGeneral_seq")
	@SequenceGenerator(name="TipoGeneral_idTipoGeneral_seq", sequenceName="TipoGeneral_idTipoGeneral_seq", allocationSize=1)
	private Integer idTipoGeneral;
	private String codigoTipo;
	private Integer idPadre;
	private String valor;
	private String descripcion;
	
	public Integer getIdTipoGeneral() {
		return idTipoGeneral;
	}
	public void setIdTipoGeneral(Integer idTipoGeneral) {
		this.idTipoGeneral = idTipoGeneral;
	}
	public String getCodigoTipo() {
		return codigoTipo;
	}
	public void setCodigoTipo(String codigoTipo) {
		this.codigoTipo = codigoTipo;
	}
	public Integer getIdPadre() {
		return idPadre;
	}
	public void setIdPadre(Integer idPadre) {
		this.idPadre = idPadre;
	}
	public String getValor() {
		return valor;
	}
	public void setValor(String valor) {
		this.valor = valor;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	

}
