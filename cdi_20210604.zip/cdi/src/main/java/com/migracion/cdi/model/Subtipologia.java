package com.migracion.cdi.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Subtipologia")
public class Subtipologia implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="Subtipologia_idSubTipologia_seq")
	@SequenceGenerator(name="Subtipologia_idSubTipologia_seq", sequenceName="Subtipologia_idSubTipologia_seq", allocationSize=1)
	private Integer idSubtipologia;
	
	private String nombre;
	private String descripcion;
	private Integer estado;
	
	@JoinColumn(name = "idTipologia", referencedColumnName = "idTipologia")
	@OneToOne(optional = false)
	private Tipologia idTipologia;
	
	public Integer getIdSubtipologia() {
		return idSubtipologia;
	}
	public void setIdSubtipologia(Integer idSubtipologia) {
		this.idSubtipologia = idSubtipologia;
	}
	public Tipologia getIdTipologia() {
		return idTipologia;
	}
	public void setIdTipologia(Tipologia idTipologia) {
		this.idTipologia = idTipologia;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public Integer getEstado() {
		return estado;
	}
	public void setEstado(Integer estado) {
		this.estado = estado;
	}
	
	

}
