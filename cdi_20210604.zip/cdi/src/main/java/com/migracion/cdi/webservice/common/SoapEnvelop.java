package com.migracion.cdi.webservice.common;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "soapenv:Envelope")
public class SoapEnvelop {
	
@XmlElement(name="soapenv:Body")
private SoapBody soapBody;

public void setSoapBody(SoapBody soapBody) {
	this.soapBody = soapBody;
}


}
