package com.migracion.cdi.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.migracion.cdi.dao.ProcesoDisciplinarDao;
import com.migracion.cdi.dao.TipoGeneralDao;
import com.migracion.cdi.model.ProcesoDisciplinar;
import com.migracion.cdi.model.TipoGeneral;

@Service
public class ProcesoDisciplinarServiceImpl implements IProcesoDisciplinarService {
	
	@Autowired
	private TipoGeneralDao tipoGeneralDao;
	
	@Autowired
	private ProcesoDisciplinarDao procesoDisciplinarDao;
	
	
	public ProcesoDisciplinarServiceImpl(){
		//SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
	}
	
	
	@Override
	@Transactional
	public void guardar(ProcesoDisciplinar procesoDisciplinar) {
		procesoDisciplinarDao.save(procesoDisciplinar);
	}
	
	


	@Override
	public ProcesoDisciplinar consultaProcesoDisciplinarPorId(Integer id) throws Exception{
		try {
			return procesoDisciplinarDao.consultaProcesoDisciplinarPorId(id);
		} catch (Exception e) {
			throw new Exception(e);		 
		}
	}


	@Override
	public String buscarUltimoCodigoExpediente() throws Exception {
		return procesoDisciplinarDao.buscarUltimoCodigoExpediente();
	}
	

}
