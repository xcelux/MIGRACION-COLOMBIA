package com.migracion.cdi.common;

import java.text.SimpleDateFormat;
import java.util.Date;

public class CDIUtil {
	
	
	public Date adicionarAnio(Date fecha) {
		
		return new Date();
	}
	
	public static String DateToString(Date fecha) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
		String fechaCadena = sdf.format(fecha);
		return fechaCadena;
	}
	
	public String anioActual() {
		Date fechaActual = new Date();
        SimpleDateFormat getYearFormat = new SimpleDateFormat("yyyy");
        String anioActual = getYearFormat.format(fechaActual).substring(2);
        return anioActual;
	}
	
	public String generarCodidgoExpediente(String codExpedienteActual) {
        String codExpedienteNuevo="";
        
            String anioUltimoExpediente = codExpedienteActual.substring(5);
            String anioActual = this.anioActual();

            if(!anioUltimoExpediente.equals(anioActual)){
                codExpedienteNuevo = "0001/"+anioActual;
            }else{

                int contador = 0;
                while(codExpedienteActual.substring(contador,contador+1).equals("0")){
                    contador++;
                }

                String numeroSinCeros = codExpedienteActual.substring(contador,4);
                Integer numeroConsecutivo = (Integer.parseInt(numeroSinCeros))+1;
                int numeroDigitos = 4 - numeroConsecutivo.toString().length();

                String nuevoConsecutivo = "";
                while(nuevoConsecutivo.length()<numeroDigitos){
                    nuevoConsecutivo = nuevoConsecutivo + "0";
                }
                nuevoConsecutivo = nuevoConsecutivo + numeroConsecutivo;
                codExpedienteNuevo = nuevoConsecutivo+"/"+anioUltimoExpediente;

            }

		return codExpedienteNuevo;
	}
	

}
