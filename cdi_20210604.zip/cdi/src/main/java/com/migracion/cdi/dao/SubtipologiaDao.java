package com.migracion.cdi.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.migracion.cdi.model.Subtipologia;

@Repository
public interface SubtipologiaDao extends CrudRepository<Subtipologia, Integer>{
	
	@Query("SELECT s FROM Subtipologia s WHERE s.estado = 1")
	public List<Subtipologia> consultaListaSubtipologias();

}