CREATE TABLE "PROCESO_DISCIPLINAR" (
	"idProceso_Disciplinar" NUMBER(7, 0) NOT NULL,
	"fecha_Recibido" DATE NOT NULL,
	"fecha_Elaboracion_Formato" DATE NOT NULL,
	"numero_Expediente" VARCHAR2(8) UNIQUE NOT NULL,
	"idInvestigado" VARCHAR2(10) NOT NULL,
	"idRadicado_Orfeo" VARCHAR2(20) NOT NULL,
	"hechos" NVARCHAR2(1000) NOT NULL,
	"fecha_hechos" DATE NOT NULL,
	"idTipologia" NUMBER(2, 0) NOT NULL,
	"estado" NUMBER(4, 0) NOT NULL,
	"idAbogado" NUMBER(1, 0) NOT NULL,
	"fecha_prescripcion" DATE,
	"fecha_apertura_indagacion" DATE,
	"prorroga_investigacion" NUMBER(3, 0),
	"decision" VARCHAR2(500),
	"fecha_decision" DATE,
	"idAllegaPor" NUMBER(3, 0) NOT NULL,
	"idEstado_Decision" NUMBER(3, 0),
	"idEtapa_Actual" NUMBER(3, 0) NOT NULL,
	"idTipo_Proceso" NUMBER(3, 0) NOT NULL,
	"idNacionalidad" NUMBER(3, 0),
	"segunda_Instancia" VARCHAR2(300),
	"devolucion_Segunda_Instancia" VARCHAR2(300),
	"fecha_Siri" VARCHAR2(300),
	constraint PROCESO_DISCIPLINAR_PK PRIMARY KEY ("idProceso_Disciplinar"));

CREATE sequence "PROCESO_DISCIPLINAR_IDPROCESO_DISCIPLINAR_SEQ";

CREATE trigger "BI_PROCESO_DISCIPLINAR_IDPROCESO_DISCIPLINAR"
  before insert on "PROCESO_DISCIPLINAR"
  for each row
begin
  select "PROCESO_DISCIPLINAR_IDPROCESO_DISCIPLINAR_SEQ".nextval into :NEW."idProceso_Disciplinar" from dual;
end;

/
CREATE TABLE "TIPOLOGIA" (
	"idTipologia" NUMBER(2, 0) NOT NULL,
	"nombre" VARCHAR2(100) NOT NULL,
	"descripcion" VARCHAR2(500) NOT NULL,
	"estado" NUMBER(4, 0) NOT NULL,
	constraint TIPOLOGIA_PK PRIMARY KEY ("idTipologia"));

CREATE sequence "TIPOLOGIA_IDTIPOLOGIA_SEQ";

CREATE trigger "BI_TIPOLOGIA_IDTIPOLOGIA"
  before insert on "TIPOLOGIA"
  for each row
begin
  select "TIPOLOGIA_IDTIPOLOGIA_SEQ".nextval into :NEW."idTipologia" from dual;
end;

/
CREATE TABLE "SUBTIPOLOGIA" (
	"idSubtipologia" NUMBER(3, 0) NOT NULL,
	"nombre" VARCHAR2(50) NOT NULL,
	"descripcion" VARCHAR2(500) NOT NULL,
	"idTipologia" NUMBER(2, 0) UNIQUE NOT NULL,
	constraint SUBTIPOLOGIA_PK PRIMARY KEY ("idSubtipologia"));

CREATE sequence "SUBTIPOLOGIA_IDSUBTIPOLOGIA_SEQ";

CREATE trigger "BI_SUBTIPOLOGIA_IDSUBTIPOLOGIA"
  before insert on "SUBTIPOLOGIA"
  for each row
begin
  select "SUBTIPOLOGIA_IDSUBTIPOLOGIA_SEQ".nextval into :NEW."idSubtipologia" from dual;
end;

/
CREATE TABLE "TIPOGENERAL" (
	"idTipoGeneral" NUMBER(3, 0) NOT NULL,
	"codigoTipo" VARCHAR2(20),
	"idPadre" NUMBER(4, 0) NOT NULL,
	"valor" NVARCHAR2(200) NOT NULL,
	"descripcion" NVARCHAR2(500) NOT NULL,
	"estado" NUMBER(2, 0) NOT NULL,
	constraint TIPOGENERAL_PK PRIMARY KEY ("idTipoGeneral"));

CREATE sequence "TIPOGENERAL_IDTIPOGENERAL_SEQ";

CREATE trigger "BI_TIPOGENERAL_IDTIPOGENERAL"
  before insert on "TIPOGENERAL"
  for each row
begin
  select "TIPOGENERAL_IDTIPOGENERAL_SEQ".nextval into :NEW."idTipoGeneral" from dual;
end;

/
ALTER TABLE "PROCESO_DISCIPLINAR" ADD CONSTRAINT "PROCESO_DISCIPLINAR_fk0" FOREIGN KEY ("idTipologia") REFERENCES "TIPOLOGIA"("idTipologia");
ALTER TABLE "PROCESO_DISCIPLINAR" ADD CONSTRAINT "PROCESO_DISCIPLINAR_fk1" FOREIGN KEY ("idAllegaPor") REFERENCES "TIPOGENERAL"("idTipoGeneral");
ALTER TABLE "PROCESO_DISCIPLINAR" ADD CONSTRAINT "PROCESO_DISCIPLINAR_fk2" FOREIGN KEY ("idEstado_Decision") REFERENCES "TIPOGENERAL"("idTipoGeneral");
ALTER TABLE "PROCESO_DISCIPLINAR" ADD CONSTRAINT "PROCESO_DISCIPLINAR_fk3" FOREIGN KEY ("idEtapa_Actual") REFERENCES "TIPOGENERAL"("idTipoGeneral");
ALTER TABLE "PROCESO_DISCIPLINAR" ADD CONSTRAINT "PROCESO_DISCIPLINAR_fk4" FOREIGN KEY ("idTipo_Proceso") REFERENCES "TIPOGENERAL"("idTipoGeneral");
ALTER TABLE "PROCESO_DISCIPLINAR" ADD CONSTRAINT "PROCESO_DISCIPLINAR_fk5" FOREIGN KEY ("idNacionalidad") REFERENCES "TIPOGENERAL"("idTipoGeneral");


ALTER TABLE "SUBTIPOLOGIA" ADD CONSTRAINT "SUBTIPOLOGIA_fk0" FOREIGN KEY ("idTipologia") REFERENCES "TIPOLOGIA"("idTipologia");


