--ALTER TABLE tipogeneral modify "descripcion" VARCHAR2(100) null;

-->TIPOLOGIAS
INSERT INTO tipologia ("nombre","descripcion","estado") VALUES ('Abandono del cargo, función o servicio','Es la ausencia injustificada del servidor, en el encargo, función o servicio durante tres días consecutivos o más.',1);
INSERT INTO tipologia ("nombre","descripcion","estado") VALUES ('Incumplimiento horario de trabajo','Es la inobservancia de la jornada laboral por parte de un servidor público de la siguiente manera: llegar tarde, ausentarse en el transcurso de la misma, retirarse antes de su culminación, no presentarse a trabajar durante uno o dos días. ',1);
INSERT INTO tipologia ("nombre","descripcion","estado") VALUES ('Irregularidades en atención a ciudadanos o autoridades','Conductas relacionadas con la mala atención o maltrato al ciudadano u otro servidor público verbal o física, la negación u omisión en la prestación del servicio debido.',1);
INSERT INTO tipologia ("nombre","descripcion","estado") VALUES ('Daño o uso irregular de elementos','Conducta relacionada con el efecto lesivo a elementos por parte del servidor público y éste da lugar a su deterioro (ejemplo: accidente de tránsito, Llevarse los vehículos para asuntos personales, uso indebido del correo institucional, daño a equipos de cómputo o celulares.).',1);
INSERT INTO tipologia ("nombre","descripcion","estado") VALUES ('Pérdida de elementos','Conducta relacionada con la pérdida o extravío de elementos que se encuentran bajo custodia o acceso al servidor público.',1);
INSERT INTO tipologia ("nombre","descripcion","estado") VALUES ('Irregularidades en los procesos de Talento Humano ','Conducta relacionada con inobservancia a las normas, procesos y procedimientos relacionados con bienestar social, capacitación, viáticos, nómina, administración de personal y seguridad social integral, calificaciones',1);
INSERT INTO tipologia ("nombre","descripcion","estado") VALUES ('Irregularidades relacionadas con el derecho de petición','Conducta relacionada con falta de respuesta de fondo, respuesta tardía, incompleta o sin la argumentación correspondiente al derecho de petición presentado por una autoridad o ciudadano.',1);
INSERT INTO tipologia ("nombre","descripcion","estado") VALUES ('Irregularidades en el trámite de una actuación administrativa','Conductas originadas en la omisión, cumplimiento tardío de los términos dentro de una actuación administrativa.',1);
INSERT INTO tipologia ("nombre","descripcion","estado") VALUES ('Incumplimiento manual de funciones y procedimientos ','Conducta omisiva o activa mediante la cual el servidor en la prestación del servicio no aplicar las funciones previstas para el cargo que ocupa o los procedimientos regulados para la dependencia en la que se encuentra.  ',1);
INSERT INTO tipologia ("nombre","descripcion","estado") VALUES ('Adulteración de documentos','Conductas relacionadas con la adulteración de un documento afectando su contenido. (CORRUPCIÒN)',1);
INSERT INTO tipologia ("nombre","descripcion","estado") VALUES ('Irregularidades en contratación estatal y temas presupuestales.','Conductas que resultan de la violación al régimen contractual y de los principios que la rigen, en las fases precontractual y postcontractual (ejm. Irregularidades en la adjudicación y en la ejecución, en la expedición del CDP, incumplir deberes interventor o supervisor contrato, interés ilícito en la celebración de contratos, uso indebido de urgencia manifiesta, violación normas reserva presupuestal, entre otros).',1);
INSERT INTO tipologia ("nombre","descripcion","estado") VALUES ('Incursión en impedimentos, inhabilidades, incompatibilidades y conflicto de intereses','Conductas descritas taxactivamente en la Constitución y la ley como impedimentos, inhabilidades, incompatibilidades o conflicto de intereses.',1);
INSERT INTO tipologia ("nombre","descripcion","estado") VALUES ('Delitos','Incurrir en conductas previstas en la ley como delitos.',1);
INSERT INTO tipologia ("nombre","descripcion","estado") VALUES ('Presentarse a laborar en estado de embriaguez o bajo efectos de alucinógenos','Conducta en la que incurre el funcionario al presentarse a laborar en estado de embriaguez o bajo el uso de drogas psicotrópicas.',1);
INSERT INTO tipologia ("nombre","descripcion","estado") VALUES ('Incumplimiento reiterado de obligaciones civiles, laborales, comerciales o de familia.','Son aquellas conductas relacionadas con el incumplimiento reiterado de este tipo de obligaciones como consecuenciade una decisión judicial que así lo declare o en razón de una diligencia de conciliación. ',1);
INSERT INTO tipologia ("nombre","descripcion","estado") VALUES ('Irregularidades en procesos de control migratorio','Permitir de manera irregular el ingreso o salida del país a ciudadanos nacionales o extranjeros, Incluye: Pérdida de los sellos, quejas relacionadas con pérdidas de dinero y objetos de los viajeros en los filtros. . (CORRUPCIÒN)',1);
INSERT INTO tipologia ("nombre","descripcion","estado") VALUES ('Irregularidades en procesos de extranjería','Prestar servicios de manera irregular a ciudadanos nacionales o extranjeros relacionados con la expedición de documentos de extranjería (documento de identidad de extranjeros) y de migración (certificado de movimientos migratorios, permisos, salvoconductos). (CORRUPCIÒN)',1);
INSERT INTO tipologia ("nombre","descripcion","estado") VALUES ('Irregularidades en procesos de verificación migratoria','Adelantar de manera irregular procesos de verificación de la situación de permanencia de extranjeros, la deportación y expulsión. (CORRUPCIÒN)',1);
INSERT INTO tipologia ("nombre","descripcion","estado") VALUES ('Uso, estudio o modificación de información reservada','Conductas relacionadas al conocimiento que tiene el funcionario público de información reservada a razón de su cargo o función y la dé a conocer o haga uso de ésta indebidamente. (CORRUPCIÒN)',1);
INSERT INTO tipologia ("nombre","descripcion","estado") VALUES ('Uso indebido del cargo o función','Aquellas conductas en la que el servidor público aprovecha de modo indebido su investidura en una situación a la que no está llamado a resolver o para cometer atropellos, desviarse de lo que legalmente le corresponde, desbordar o restringir indebidamente sus límites para fines protervos.',1);
INSERT INTO tipologia ("nombre","descripcion","estado") VALUES ('Otros','Aquí se tipifican aquellas otras conductas que no se enmarcan dentro de las anteriores tipologías.',1);

-->SUBTIPOLOGIAS
INSERT INTO subtipologia ("nombre","descripcion","idTipologia") VALUES ('Subtipologia 1 de Prueba','Descripcion de Prueba 1',30);
INSERT INTO subtipologia ("nombre","descripcion","idTipologia") VALUES ('Subtipologia 2 de Prueba','Descripcion de Prueba 1',31);



-->TIPOSGENERALES
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (0,'FuenteDatos','Tabla que almacena las diferentes fuentes de datos de una queja',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (1,'CVAC+',' ',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (1,'Informe',' ',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (1,'Queja',' ',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (1,'Noticia',' ',1);

INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (0,'EstadoDecision','Tabla que almacena los diferentes estados de decisión que puede tener un proceso disciplinar',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (7,'Evaluación',' ',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (7,'Finalizado',' ',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (7,'Instrucción',' ',1);

INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (0,'ETAPA','Tabla que almacena las diferentes etapas de un proceso disciplinar',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (21,'Noticia disciplinaria',' ',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (21,'Indagación preliminar',' ',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (21,'Investigación disciplinaria',' ',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (21,'Cierre de investigación disciplinaria',' ',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (21,'Pliego de cargos',' ',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (21,'Descargos',' ',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (21,'Pruebas',' ',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (21,'Alegatos de conclusión',' ',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (21,'Fallo de primera instancia',' ',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (21,'Fallo de segunda instancia',' ',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (21,'Citación a audiencia',' ',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (21,'Lectura de citación',' ',1);


--SELECT * FROM tipogeneral where "idPadre" = 0;


INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (0,'TipoProceso','Tabla que almacena las diferentes nacionalidades de los sujetos disciplinarios',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (34,'Ordinario',' ',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (34,'Verbal',' ',1);


INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (0,'Nacionalidad','Tabla en la que se almacenan los tipos de procesos disciplinarios',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (37,'ALEMANA',' ',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (37,'COLOMBIANO',' ',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (37,'ESPAÑOLA',' ',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (37,'VENEZOLANO',' ',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (37,'ARGENTINO',' ',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (37,'BRITANICA',' ',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (37,'CHINA',' ',1);
INSERT INTO tipogeneral ("idPadre","valor","descripcion","estado") VALUES (37,'ESTADOUNIDENSE',' ',1);
