package com.migracion.cdi.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.migracion.cdi.model.Subtipologia;

@Repository
public interface SubtipologiaDao extends CrudRepository<Subtipologia, Integer>{
	
	@Query("SELECT s FROM Subtipologia s WHERE s.estado = 1 order by idSubtipologia desc")
	public List<Subtipologia> consultaListaSubtipologias();
	
	@Query("SELECT s FROM Subtipologia s WHERE s.idTipologia.idTipologia = :idTipologia order by s.nombre")
	public List<Subtipologia> buscarSubtipologiasPorIdTipologia(Integer idTipologia);
	
	@Transactional
	@Modifying
	@Query("UPDATE Subtipologia s SET s.estado = 0 WHERE s.idSubtipologia = :idSubtipologia")
	public void desactivarSubTipologia(Integer idSubtipologia);

}