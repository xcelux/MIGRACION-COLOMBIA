package com.migracion.cdi.service;

import java.util.List;

import com.migracion.cdi.common.exception.MigracionException;
import com.migracion.cdi.model.Subtipologia;

public interface ISubtipologiaService {
	
	public List<Subtipologia> consultaListaSubtipologias() throws MigracionException;
	public List<Subtipologia> buscarSubtipologiasPorIdTipologia(Integer idTipologia) throws MigracionException;
	public void guardar(Subtipologia subtipologia) throws MigracionException;
	public void desactivar(Integer idSubTipologia) throws MigracionException;

}