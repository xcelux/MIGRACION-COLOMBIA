package com.migracion.cdi.common;

public class MensajesCTE {
	
	public static final String MENSAJE_EXITOSO="Proceso de '%s' en la entidad '%s' fue realizada exitosamente!";
	public static final String MENSAJE_FALLIDO_CREAR="Ha ocurrido un error al crear %s";
	public static final String MENSAJE_ERROR_LOG="Ha ocurrido un error en el metodo: '%s' de la clase '%s' ";
	public static final String MENSAJE_FALLIDO_CONSULTAR_TODO="Ha ocurrido un error al consultar todos los registros de %s";
	
	public static final String MENSAJE_ERROR_GENERAL="Ha ocurrido un error interno. Vuelva a ejecutar el proceso. Si persiste el error, póngase en contacto con el administrador.";

}
