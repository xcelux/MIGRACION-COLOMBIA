package com.migracion.cdi.common;

public class GeneralCTE {

	
	// acciones
	public static final String PROCESO_CREAR = "Crear";
	public static final String PROCESO_EDITAR = "Editar";
	public static final String PROCESO_ELIMINAR = "Eliminar";
	public static final String PROCESO_CONSULTAR = "Consultar";
	public static final String PROCESO_CONSULTAR_TODO = "Consultar todo";
	public static final String PROCESO_CONSULTAR_PERSONALIZADA = "Consulta personalizada";
	
	
	//clases y metodos
	public static final String CLASE_PROCESODISCIPLINAR_IMPL = "ProcesoDisciplinarServiceImpl";
	public static final String METODO_CREAR_PROCESODISCIPLINAR = "guardar(ProcesoDisciplinar procesoDisciplinar)";
	public static final String METODO_BUSCAR_ULTIMO_CODIGO_EXPEDIENTE = "buscarUltimoCodigoExpediente()";
	public static final String METODO_BUSCAR_ULTIMO_PROCESO_DISCIPLINAR = "buscarUltimoProcesoDisciplinar()";
	
	public static final String CLASE_TIPOGENERAL_IMPL = "TipoGeneralServiceImpl";
	public static final String METODO_CONSULTAR_TIPOSGENERAL_POR_VALOR = "buscarTiposGeneralesPorValor(String valor)";
	public static final String METODO_CONSULTAR_TIPOGENERAL_POR_VALOR = "buscarTipoGeneralesPorValor(String valor)";
	
	
	public static final String CLASE_TIPOLOGIA_IMPL = "TipologiaServiceImpl";
	public static final String METODO_CONSULTAR_TIPOLOGIAS = "consultaListaTipologias()";
	public static final String METODO_DESACTIVAR_TIPOLOGIAS = "desactivar(Integer idTipologia)";
	public static final String METODO_CREAR_TIPOLOGIA = "guardar(Tipologia tipologia)";
	
	public static final String CLASE_SUBTIPOLOGIA_IMPL = "SubtipologiaServiceImpl";
	public static final String METODO_CONSULTAR_SUBTIPOLOGIAS = "consultaListaSubtipologias()";
	public static final String METODO_CONSULTAR_SUBTIPOLOGIAS_ID = "buscarSubtipologiasPorIdTipologia(Integer idTipologia)";
	public static final String METODO_CREAR_SUBTIPOLOGIA = "guardar(Tipologia tipologia)";
	public static final String METODO_DESACTIVAR_SUBTIPOLOGIAS = "desactivar(Integer idSubTipologia)";
	
	
	
}
