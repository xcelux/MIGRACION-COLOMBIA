package com.migracion.cdi.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.migracion.cdi.model.TipoGeneral;

@Repository
public interface TipoGeneralDao extends CrudRepository<TipoGeneral, Integer> {
	
	@Query("SELECT t FROM TipoGeneral t WHERE t.idPadre = (SELECT t.idTipoGeneral FROM TipoGeneral t WHERE t.valor = :valor)  order by t.valor ")
	public List<TipoGeneral> buscarTiposGeneralesPorValor(String valor);
	
	@Query("SELECT t FROM TipoGeneral t WHERE t.idPadre = :idPadre order by t.valor")
	public List<TipoGeneral> buscarTiposGeneralesPorIdPadre(Integer idPadre);
	
	@Query("SELECT t FROM TipoGeneral t WHERE t.valor = :valor")
	public TipoGeneral buscarTipoGeneralPorValor(String valor);
	
	/*@Query("SELECT t FROM TipoGeneral t WHERE t.codigoTipo = :codigoTipo")
	public TipoGeneral consultaListaTiposGeneralesPorCodigo(String codigoTipo);
	
	@Query(value = "SELECT \"IdTipoGeneral\" FROM parametria.\"TipoGeneral\" WHERE \"CodigoTipo\" in (:codigoTipo);", nativeQuery = true)
	List<Integer> buscarIdTipoGeneralesPorCodigosTipo(String... codigoTipo);
	
	*/
}
