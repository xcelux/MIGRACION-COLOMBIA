package com.migracion.cdi;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.migracion.cdi.controller.Conexion;


@SpringBootApplication
public class CdiApplication {
	
	public static void main(String[] args) {
	SpringApplication.run(CdiApplication.class, args);
	//Conexion conexion = new Conexion();
		//conexion.ConexionManager("72292500C","B4np0pul4r_24");
	}

	
}
