package com.migracion.cdi.controller;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.migracion.cdi.common.CDIUtil;
import com.migracion.cdi.common.MensajesCTE;
import com.migracion.cdi.model.InvestigadoProceso;
import com.migracion.cdi.model.ProcesoDisciplinar;
import com.migracion.cdi.model.Subtipologia;
import com.migracion.cdi.model.TipoGeneral;
import com.migracion.cdi.model.Tipologia;
import com.migracion.cdi.service.IInvestigadoProcesoService;
import com.migracion.cdi.service.IProcesoDisciplinarService;
import com.migracion.cdi.service.ISubtipologiaService;
import com.migracion.cdi.service.ITipoGeneralService;
import com.migracion.cdi.service.ITipologiaService;

import lombok.extern.slf4j.Slf4j;



@Controller
@RequestMapping(value="/proceso")
@Slf4j
public class ProcesoDisciplinarController {	
	
	@Autowired
	private IProcesoDisciplinarService procesoDisciplinarService;
	
	@Autowired
	private ITipoGeneralService tipoGeneralService;
	
	@Autowired
	private ITipologiaService tipologiaService;
	
	@Autowired
	private ISubtipologiaService subtipologiaService;
	
	@Autowired
	private IInvestigadoProcesoService investigadoProcesoService;
	
	private CDIUtil cdiUtil = new CDIUtil();
	
	List<InvestigadoProceso> listaFuncionariosSelect;
	
	@GetMapping("/prepararBuscar")
	public String prepararBuscar() {
		return "proceso/buscar";
	}
	
	
	@GetMapping("/prepararCrear")
	public String mostrarHome(Model model, HttpSession session) {
		
		String url= "/proceso/crear";
		
		List<TipoGeneral> nacionalidadesSelect = new LinkedList<TipoGeneral>();
		List<TipoGeneral> regionalesSelect     = new LinkedList<TipoGeneral>();
		List<TipoGeneral> fuenteDatosSelect    = new LinkedList<TipoGeneral>();
		List<TipoGeneral> tipoProcesoSelect    = new LinkedList<TipoGeneral>();
		List<TipoGeneral> tipoQuejosoSelect    = new LinkedList<TipoGeneral>();
		List<TipoGeneral> tipoDocumentoQuejosoSelect = new LinkedList<TipoGeneral>();
		List<Tipologia> tipologiaSelect = new LinkedList<Tipologia>();
		
		listaFuncionariosSelect = new LinkedList<InvestigadoProceso>();
				
		try {
			
			nacionalidadesSelect 		  = tipoGeneralService.buscarTiposGeneralesPorValor("Nacionalidad");
			regionalesSelect     		  = tipoGeneralService.buscarTiposGeneralesPorValor("Regional");
			fuenteDatosSelect    		  = tipoGeneralService.buscarTiposGeneralesPorValor("FuenteDatos");
			tipoProcesoSelect    		  = tipoGeneralService.buscarTiposGeneralesPorValor("TipoProceso");
			tipoQuejosoSelect    		  = tipoGeneralService.buscarTiposGeneralesPorValor("TipoQuejoso");
			tipoDocumentoQuejosoSelect    = tipoGeneralService.buscarTiposGeneralesPorValor("TipoDocumentoQuejoso");
			tipologiaSelect               = tipologiaService.consultaListaTipologias();
			listaFuncionariosSelect       = investigadoProcesoService.consultarInvestigados();
			
			session.setAttribute("nacionalidadesSelect", nacionalidadesSelect);
			session.setAttribute("regionalesSelect", regionalesSelect);
			session.setAttribute("fuenteDatosSelect", fuenteDatosSelect);
			session.setAttribute("tipoProcesoSelect", tipoProcesoSelect);
			session.setAttribute("tipoQuejosoSelect", tipoQuejosoSelect);
			session.setAttribute("tipoDocumentoQuejosoSelect", tipoDocumentoQuejosoSelect);
			session.setAttribute("tipologiaSelect", tipologiaSelect);
			session.setAttribute("listaFuncionariosSelect", listaFuncionariosSelect);
			

			model.addAttribute("listaFuncionariosSelect",listaFuncionariosSelect);
			
			
			//linea de codigo creada exclusivamente para probar relacion entre tablas
			//ProcesoDisciplinar procesoDisciplinar = new ProcesoDisciplinar();
			//procesoDisciplinar = procesoDisciplinarService.consultaProcesoDisciplinarPorId(44);
			
			//linea de codigo creada exclusivamente para probar relacion entre tablas
			//List<InvestigadoProceso> listInvestigado = new LinkedList<InvestigadoProceso>();
			//listInvestigado = investigadoProcesoService.consultarPorInvestigado(1);
			
		} catch (Exception e) {
			log.error(MensajesCTE.MENSAJE_ERROR_GENERAL);
			model.addAttribute("msg", MensajesCTE.MENSAJE_ERROR_GENERAL);
			return url;
		}
		
		return url;
	}
	
	
	@RequestMapping(value="/guardar", method = RequestMethod.POST)
	public String guardar(ProcesoDisciplinar procesoDisciplinar, BindingResult result, RedirectAttributes attributes, @RequestParam("investigados") Integer[] investigados) {
		
		String url= "redirect:/proceso/prepararCrear";
		
		if(result.hasErrors()) {
			for(ObjectError error: result.getAllErrors()) {
				log.error("Ocurrio un error: "+error.getDefaultMessage());
			}
			
			return url;
		}
		
		
		try {
			
			String ultimoCodigoExpediente = procesoDisciplinarService.buscarUltimoCodigoExpediente();
			if(ultimoCodigoExpediente==null) {
				procesoDisciplinar.setNumeroExpediente("0001/"+cdiUtil.anioActual());
			}else {
				procesoDisciplinar.setNumeroExpediente(cdiUtil.generarCodidgoExpediente(ultimoCodigoExpediente));
			}
			
			procesoDisciplinar.setNumeroExpediente(null);
			TipoGeneral estadoDecision = new TipoGeneral();
			estadoDecision = tipoGeneralService.buscarTipoGeneralesPorValor("Evaluacion");
			
			TipoGeneral etapa = new TipoGeneral();
			etapa = tipoGeneralService.buscarTipoGeneralesPorValor("Evaluar Noticia");
			
			procesoDisciplinar.setEstado(1);
			procesoDisciplinar.setFechaElaboracionFormato(new Date());
			procesoDisciplinar.setIdRadicadoOrfeo("6251-1");
			procesoDisciplinar.setIdEstadoDecision(estadoDecision);
			procesoDisciplinar.setIdEtapaActual(etapa);
	
			
			procesoDisciplinarService.guardar(procesoDisciplinar);
			
			int idProcesoDisciplinar = procesoDisciplinarService.buscarUltimoProcesoDisciplinar();
			
			List<InvestigadoProceso> listaInvestigados = cdiUtil.obtenerListaInvestigadosPorId(listaFuncionariosSelect, investigados, idProcesoDisciplinar);
			
			for(int i=0;i<listaInvestigados.size();i++) {
				investigadoProcesoService.guardar(listaInvestigados.get(i));
			}
			
		
		}catch (Exception e) {	
			log.error(MensajesCTE.MENSAJE_ERROR_GENERAL);
			attributes.addFlashAttribute("msg", MensajesCTE.MENSAJE_ERROR_GENERAL);
			return url;
		}
		
		
		attributes.addFlashAttribute("msg","Proceso Guardado Satisfactoriamente. --> Proceso disciplinario creado, número de expediente "+procesoDisciplinar.getNumeroExpediente());
		return url;
		
	}
	
	
	@GetMapping(value = "/buscar")
	public String buscarProcesoDisciplinar(Model model, String criterioSeleccionado, String valorDigitado) {
		
		List<ProcesoDisciplinar> procesoDisciplinar = new LinkedList<ProcesoDisciplinar>();
		List<InvestigadoProceso> investigadoProceso = new LinkedList<InvestigadoProceso>();
		
		try {
			
			if("1".equals(criterioSeleccionado)) {
				
				procesoDisciplinar = procesoDisciplinarService.consultaProcesoDisciplinarPorExpediente(valorDigitado);
				model.addAttribute("procesoDisciplinar", procesoDisciplinar);
				
			}else if("2".equals(criterioSeleccionado)) {
				
				//implementar con orfeo
				
			}else if("3".equals(criterioSeleccionado)) {
				
				Integer valorDigitadoEntero = Integer.parseInt(valorDigitado);
				investigadoProceso = investigadoProcesoService.consultarPorInvestigado(valorDigitadoEntero);
				
				/*String in = "(";
				for (int i=0; i<investigadoProceso.size(); i++) {
					in = in + investigadoProceso.get(i).getIdProcesoDisciplinar().getIdProcesoDisciplinar()+",";
				}
				
				in= in.substring(0,in.length()-1);
				in= in + ")";*/
				
				Integer [] in = new Integer[investigadoProceso.size()];
				
				for (int i=0; i<investigadoProceso.size(); i++) {
					
					in[i] = investigadoProceso.get(i).getIdProcesoDisciplinar().getIdProcesoDisciplinar();
				}
						
				procesoDisciplinar = procesoDisciplinarService.findByIdProcesoDisciplinarIn(in);
				
				System.out.println(procesoDisciplinar.get(0).getListaInvestigados().get(0).getNombreInvestigado());
				
				model.addAttribute("procesoDisciplinar", procesoDisciplinar);
				
				
			}else if("4".equals(criterioSeleccionado)) {
				
				// implementacion
			}
			
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "proceso/buscar";
		
		
	}
	
	
	@ResponseBody
	@GetMapping("/dependencias/{idRegional}")
	public List<TipoGeneral> buscarDependencias(@PathVariable("idRegional") Integer idRegional) throws Exception {
		List<TipoGeneral> dependenciasSelect = new LinkedList<TipoGeneral>();
		dependenciasSelect = tipoGeneralService.buscarTiposGeneralesPorIdPadre(idRegional);
		return dependenciasSelect;
	}
	
	@ResponseBody
	@GetMapping("/subtipologias/{idTipologia}")
	public List<Subtipologia> buscarSubtipologias(@PathVariable("idTipologia") Integer idTipologia) throws Exception {
		List<Subtipologia> subtipologiasSelect = new LinkedList<Subtipologia>();
		subtipologiasSelect = subtipologiaService.buscarSubtipologiasPorIdTipologia(idTipologia);
		return subtipologiasSelect;
	}
	
	
	@InitBinder
	public void initBinder(WebDataBinder webDataBinder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		dateFormat.setLenient(false);
		webDataBinder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat,true));
	}
	

}
