package com.migracion.cdi.service;

import java.util.List;

import com.migracion.cdi.common.exception.MigracionException;
import com.migracion.cdi.model.InvestigadoProceso;

public interface IInvestigadoProcesoService {

	public void guardar(InvestigadoProceso investigadoProceso);
	
	public List<InvestigadoProceso> consultarPorInvestigado(Integer investigado) throws Exception;
	public List<InvestigadoProceso> consultarInvestigados() throws MigracionException;
}
