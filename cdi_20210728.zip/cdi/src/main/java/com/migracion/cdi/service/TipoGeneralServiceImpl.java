package com.migracion.cdi.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.migracion.cdi.common.GeneralCTE;
import com.migracion.cdi.common.MensajesCTE;
import com.migracion.cdi.common.exception.MigracionException;
import com.migracion.cdi.dao.TipoGeneralDao;
import com.migracion.cdi.model.TipoGeneral;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class TipoGeneralServiceImpl implements ITipoGeneralService{
	
	
	@Autowired
	private TipoGeneralDao tipoGeneralDao;
	
	@Override
	@Transactional(readOnly = true)
	public List<TipoGeneral> buscarTiposGeneralesPorValor(String valor) throws MigracionException {
		try {
		return tipoGeneralDao.buscarTiposGeneralesPorValor(valor);
		} catch (Exception e) {
			String mensajeError = String.format(MensajesCTE.MENSAJE_ERROR_LOG, GeneralCTE.METODO_CONSULTAR_TIPOSGENERAL_POR_VALOR, GeneralCTE.CLASE_TIPOGENERAL_IMPL);
			log.error(mensajeError);
			throw new MigracionException(mensajeError, e);		 
		}
	}

	@Override
	public TipoGeneral buscarTipoGeneralesPorValor(String valor) throws MigracionException {
		try {
			return (TipoGeneral) tipoGeneralDao.buscarTipoGeneralPorValor(valor);
			} catch (Exception e) {
				String mensajeError = String.format(MensajesCTE.MENSAJE_ERROR_LOG, GeneralCTE.METODO_CONSULTAR_TIPOGENERAL_POR_VALOR, GeneralCTE.CLASE_TIPOGENERAL_IMPL);
				log.error(mensajeError);
				throw new MigracionException(mensajeError, e);		 
			}
	}

	@Override
	public List<TipoGeneral> buscarTiposGeneralesPorIdPadre(Integer idPadre) throws Exception {
		try {
			return tipoGeneralDao.buscarTiposGeneralesPorIdPadre(idPadre);
			} catch (Exception e) {
				//log.error(MensajeLog.MENSAJE_ERROR_LOG,e);
				String mensajeError =String.format(MensajesCTE.MENSAJE_FALLIDO_CONSULTAR_TODO);		
				throw new Exception(mensajeError,e);		 
			}
	}
	
	
}
