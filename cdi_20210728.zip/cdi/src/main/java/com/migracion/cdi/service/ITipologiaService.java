package com.migracion.cdi.service;

import java.util.List;

import com.migracion.cdi.common.exception.MigracionException;
import com.migracion.cdi.model.Tipologia;

public interface ITipologiaService {
	
	public List<Tipologia> consultaListaTipologias() throws MigracionException;
	public void guardar(Tipologia tipologia) throws MigracionException;
	public void desactivar(Integer idTipologia) throws MigracionException;

}
