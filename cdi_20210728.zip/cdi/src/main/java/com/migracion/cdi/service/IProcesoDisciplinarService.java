package com.migracion.cdi.service;


import com.migracion.cdi.common.exception.MigracionException;
import com.migracion.cdi.model.InvestigadoProceso;
import com.migracion.cdi.model.ProcesoDisciplinar;
import java.util.List;

public interface IProcesoDisciplinarService {
	
	public void guardar(ProcesoDisciplinar procesoDisciplinar) throws MigracionException;
	public ProcesoDisciplinar consultaProcesoDisciplinarPorId(Integer id) throws Exception;
	public String buscarUltimoCodigoExpediente() throws MigracionException;
	public Integer buscarUltimoProcesoDisciplinar()throws MigracionException;
	
	public List<ProcesoDisciplinar> consultaProcesoDisciplinarPorExpediente(String expediente) throws Exception;
	public List<ProcesoDisciplinar> consultaProcesoDisciplinarPorInvestigado(Integer investigado) throws Exception;
	public List<ProcesoDisciplinar> findByIdProcesoDisciplinarIn(Integer[] ids)throws Exception;
	
}
