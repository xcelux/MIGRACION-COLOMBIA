package com.migracion.cdi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.migracion.cdi.common.GeneralCTE;
import com.migracion.cdi.common.MensajesCTE;
import com.migracion.cdi.common.exception.MigracionException;
import com.migracion.cdi.dao.SubtipologiaDao;
import com.migracion.cdi.model.Subtipologia;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SubtipologiaServiceImpl implements ISubtipologiaService{
	
	@Autowired
	private SubtipologiaDao subtipologiaDao;
	
	@Override
	@Transactional(readOnly = true)
	public List<Subtipologia> consultaListaSubtipologias() throws MigracionException {
		try {
			return subtipologiaDao.consultaListaSubtipologias();
		}catch (Exception e) {
			String mensajeError = String.format(MensajesCTE.MENSAJE_ERROR_LOG, GeneralCTE.METODO_CONSULTAR_SUBTIPOLOGIAS, GeneralCTE.CLASE_SUBTIPOLOGIA_IMPL);
			log.error(mensajeError);
			throw new MigracionException(mensajeError, e);		 
		}
	}

	@Override
	public List<Subtipologia> buscarSubtipologiasPorIdTipologia(Integer idTipologia) throws MigracionException {
		try {
			return subtipologiaDao.buscarSubtipologiasPorIdTipologia(idTipologia);
		}catch (Exception e) {
			String mensajeError = String.format(MensajesCTE.MENSAJE_ERROR_LOG, GeneralCTE.METODO_CONSULTAR_SUBTIPOLOGIAS_ID, GeneralCTE.CLASE_SUBTIPOLOGIA_IMPL);
			log.error(mensajeError);
			throw new MigracionException(mensajeError, e);		 
		}
	}

	@Override
	public void guardar(Subtipologia subtipologia) throws MigracionException {
		try {
			subtipologiaDao.save(subtipologia);
		}catch (Exception e) {
			String mensajeError = String.format(MensajesCTE.MENSAJE_ERROR_LOG, GeneralCTE.METODO_CREAR_SUBTIPOLOGIA, GeneralCTE.CLASE_SUBTIPOLOGIA_IMPL);
			log.error(mensajeError);
			throw new MigracionException(mensajeError, e);
		}
		
	}

	@Override
	public void desactivar(Integer idSubTipologia) throws MigracionException {
		try {
			subtipologiaDao.desactivarSubTipologia(idSubTipologia);
		} catch (Exception e) {
			String mensajeError = String.format(MensajesCTE.MENSAJE_ERROR_LOG, GeneralCTE.METODO_DESACTIVAR_SUBTIPOLOGIAS, GeneralCTE.CLASE_SUBTIPOLOGIA_IMPL);
			log.error(mensajeError);
			throw new MigracionException(mensajeError, e);		 
		}
		
	}

}
