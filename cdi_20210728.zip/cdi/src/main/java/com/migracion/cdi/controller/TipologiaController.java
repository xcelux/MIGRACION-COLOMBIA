package com.migracion.cdi.controller;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.migracion.cdi.common.MensajesCTE;
import com.migracion.cdi.common.exception.MigracionException;
import com.migracion.cdi.model.Tipologia;
import com.migracion.cdi.service.ITipologiaService;

import lombok.extern.slf4j.Slf4j;

@Controller
@RequestMapping(value="/tipologia")
@Slf4j
public class TipologiaController {
	
	@Autowired
	private ITipologiaService tipologiaService;
	
	@GetMapping("/buscar")
	public String buscar(Model model) {
		String url= "/administracion/tipologia";
		
		List<Tipologia> listaTipologias = new LinkedList<Tipologia>();
		
		try {
			
			listaTipologias  = tipologiaService.consultaListaTipologias();
			model.addAttribute("listaTipologias",listaTipologias);
		} catch (MigracionException e) {
			e.printStackTrace();
		}
		return url;
	}
	
	@RequestMapping(value="/guardar", method = RequestMethod.POST)
	public String guardar(Tipologia tipologia, BindingResult result) {
		String url= "redirect:/tipologia/buscar";
		
		try {
				tipologia.setEstado(1);
				tipologiaService.guardar(tipologia);

		}catch (Exception e) {	
			log.error(MensajesCTE.MENSAJE_ERROR_GENERAL);
			//attributes.addFlashAttribute("msg", MensajesCTE.MENSAJE_ERROR_GENERAL);
			return url;
		}
		
		
		//attributes.addFlashAttribute("msg","Proceso Guardado Satisfactoriamente. --> Proceso disciplinario creado, número de expediente ");
		return url;
		
	}
	
	@GetMapping("/desactivar/{id}")
	public String desactivar(@PathVariable("id") int idTipologia) {
		String url= "redirect:/tipologia/buscar";
		try {
			tipologiaService.desactivar(idTipologia);
		}catch (Exception e) {	
			log.error(MensajesCTE.MENSAJE_ERROR_GENERAL);
			return url;
		}
		return url;
		
	}

}
