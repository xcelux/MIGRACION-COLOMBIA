package com.migracion.cdi.controller;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.migracion.cdi.common.MensajesCTE;
import com.migracion.cdi.common.exception.MigracionException;
import com.migracion.cdi.model.Subtipologia;
import com.migracion.cdi.service.ISubtipologiaService;

import lombok.extern.slf4j.Slf4j;

@Controller
@RequestMapping(value="/subtipologia")
@Slf4j
public class SubtipologiaController {
	
	@Autowired
	private ISubtipologiaService subtipologiaService;
	
	@GetMapping("/buscar")
	public String buscar(Model model) {
		String url= "/administracion/subtipologia";
		
		List<Subtipologia> listaSubtipologias = new LinkedList<Subtipologia>();
		
		try {
			
			listaSubtipologias  = subtipologiaService.consultaListaSubtipologias();
			model.addAttribute("listaSubtipologias",listaSubtipologias);
		} catch (MigracionException e) {
			e.printStackTrace();
		}
		return url;
	}
	
	@RequestMapping(value="/guardar", method = RequestMethod.POST)
	public String guardar(Subtipologia subtipologia, BindingResult result) {
		String url= "redirect:/subtipologia/buscar";
		
		try {
				subtipologia.setEstado(1);
				subtipologiaService.guardar(subtipologia);

		}catch (Exception e) {	
			log.error(MensajesCTE.MENSAJE_ERROR_GENERAL);
			return url;
		}
		
		
		//attributes.addFlashAttribute("msg","Proceso Guardado Satisfactoriamente. --> Proceso disciplinario creado, número de expediente ");
		return url;
		
	}
	
	@GetMapping("/desactivar/{id}")
	public String desactivar(@PathVariable("id") int idSubTipologia) {
		String url= "redirect:/subtipologia/buscar";
		try {
			subtipologiaService.desactivar(idSubTipologia);
		}catch (Exception e) {	
			log.error(MensajesCTE.MENSAJE_ERROR_GENERAL);
			return url;
		}
		return url;
		
	}

}
