package com.migracion.cdi.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.migracion.cdi.model.Tipologia;

@Repository
public interface TipologiaDao extends JpaRepository<Tipologia, Integer>{
	
	@Query("SELECT t FROM Tipologia t WHERE t.estado = 1 order by idTipologia desc")
	public List<Tipologia> consultaListaTipologias();
	
	@Transactional
	@Modifying
	@Query("UPDATE Tipologia t SET t.estado = 0 WHERE t.idTipologia = :idTipologia")
	public void desactivarTipologia(Integer idTipologia);

}
