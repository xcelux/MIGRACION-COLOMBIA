package com.migracion.cdi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.migracion.cdi.common.GeneralCTE;
import com.migracion.cdi.common.MensajesCTE;
import com.migracion.cdi.common.exception.MigracionException;
import com.migracion.cdi.dao.TipologiaDao;
import com.migracion.cdi.model.Tipologia;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class TipologiaServiceImpl implements ITipologiaService{
	
	@Autowired
	private TipologiaDao tipologiaDao;
	
	@Override
	@Transactional(readOnly = true)
	public List<Tipologia> consultaListaTipologias() throws MigracionException {
		try {
			return tipologiaDao.consultaListaTipologias();
		} catch (Exception e) {
			String mensajeError = String.format(MensajesCTE.MENSAJE_ERROR_LOG, GeneralCTE.METODO_CONSULTAR_TIPOLOGIAS, GeneralCTE.CLASE_TIPOLOGIA_IMPL);
			log.error(mensajeError);
			throw new MigracionException(mensajeError, e);		 
		}
	}

	@Override
	public void guardar(Tipologia tipologia) throws MigracionException {
		
		try {
			tipologiaDao.save(tipologia);
		}catch (Exception e) {
			String mensajeError = String.format(MensajesCTE.MENSAJE_ERROR_LOG, GeneralCTE.METODO_CREAR_TIPOLOGIA, GeneralCTE.CLASE_TIPOLOGIA_IMPL);
			log.error(mensajeError);
			throw new MigracionException(mensajeError, e);
		}
		
	}

	@Override
	public void desactivar(Integer idTipologia) throws MigracionException {
		try {
			 tipologiaDao.desactivarTipologia(idTipologia);
		} catch (Exception e) {
			String mensajeError = String.format(MensajesCTE.MENSAJE_ERROR_LOG, GeneralCTE.METODO_DESACTIVAR_TIPOLOGIAS, GeneralCTE.CLASE_TIPOLOGIA_IMPL);
			log.error(mensajeError);
			throw new MigracionException(mensajeError, e);		 
		}
		
	}

}
