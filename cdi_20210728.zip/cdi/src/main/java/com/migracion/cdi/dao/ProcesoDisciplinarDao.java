package com.migracion.cdi.dao;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.migracion.cdi.model.ProcesoDisciplinar;

@Repository
public interface ProcesoDisciplinarDao extends JpaRepository<ProcesoDisciplinar, Integer> {
	
	@Query("SELECT p FROM ProcesoDisciplinar p WHERE p.idProcesoDisciplinar = :id")
	public ProcesoDisciplinar consultaProcesoDisciplinarPorId(Integer id);
	
	@Query(value = " SELECT  numeroexpediente FROM procesodisciplinar WHERE fechaelaboracionformato = (SELECT max(fechaelaboracionformato) FROM procesodisciplinar)", nativeQuery = true)
	public String buscarUltimoCodigoExpediente();
	
	@Query(value = " SELECT  max(idProcesoDisciplinar) FROM procesodisciplinar ", nativeQuery = true)
	public Integer buscarUltimoProcesoDisciplinar();
	
	@Query("SELECT p FROM ProcesoDisciplinar p WHERE p.numeroExpediente = :exp")
	public List<ProcesoDisciplinar> consultaProcesoDisciplinarPorExpediente(String exp);
	
	@Query(value = "SELECT p.* "
			+ "FROM ProcesoDisciplinar p inner join InvestigadoProceso ip on(p.idProcesoDisciplinar = ip.idProcesoDisciplinar) "
			+ "WHERE ip.idInvestigado = :inves", nativeQuery = true)
	public List<ProcesoDisciplinar> consultaProcesoDisciplinarPorInvestigado(Integer inves);
	
	
	public List<ProcesoDisciplinar> findByIdProcesoDisciplinarIn(Integer[] ids);

}
