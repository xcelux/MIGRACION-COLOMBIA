package com.migracion.cdi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.migracion.cdi.common.GeneralCTE;
import com.migracion.cdi.common.MensajesCTE;
import com.migracion.cdi.common.exception.MigracionException;
import com.migracion.cdi.dao.ProcesoDisciplinarDao;
import com.migracion.cdi.model.ProcesoDisciplinar;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProcesoDisciplinarServiceImpl implements IProcesoDisciplinarService {
	
	@Autowired
	private ProcesoDisciplinarDao procesoDisciplinarDao;
	
	
	public ProcesoDisciplinarServiceImpl(){
	}
	
	
	@Override
	@Transactional
	public void guardar(ProcesoDisciplinar procesoDisciplinar) throws MigracionException{
		try {
			procesoDisciplinarDao.save(procesoDisciplinar);
		}catch (Exception e) {
			String mensajeError = String.format(MensajesCTE.MENSAJE_ERROR_LOG, GeneralCTE.METODO_CREAR_PROCESODISCIPLINAR, GeneralCTE.CLASE_PROCESODISCIPLINAR_IMPL);
			log.error(mensajeError);
			throw new MigracionException(mensajeError, e);
		}
	}
	
	


	@Override
	public ProcesoDisciplinar consultaProcesoDisciplinarPorId(Integer id) throws Exception{
		try {
			return procesoDisciplinarDao.consultaProcesoDisciplinarPorId(id);
		} catch (Exception e) {
			throw new Exception(e);		 
		}
	}


	@Override
	public String buscarUltimoCodigoExpediente() throws MigracionException {
		try {
			return procesoDisciplinarDao.buscarUltimoCodigoExpediente();
		}catch (Exception e) {
			String mensajeError = String.format(MensajesCTE.MENSAJE_ERROR_LOG, GeneralCTE.METODO_BUSCAR_ULTIMO_CODIGO_EXPEDIENTE, GeneralCTE.CLASE_PROCESODISCIPLINAR_IMPL);
			log.error(mensajeError);
			throw new MigracionException(mensajeError, e);
		}
	}


	@Override
	public Integer buscarUltimoProcesoDisciplinar() throws MigracionException {
		try {
			return procesoDisciplinarDao.buscarUltimoProcesoDisciplinar();
		}catch (Exception e) {
			String mensajeError = String.format(MensajesCTE.MENSAJE_ERROR_LOG, GeneralCTE.METODO_BUSCAR_ULTIMO_PROCESO_DISCIPLINAR, GeneralCTE.CLASE_PROCESODISCIPLINAR_IMPL);
			log.error(mensajeError);
			throw new MigracionException(mensajeError, e);
		}
		
	}
	
	@Override
	public List<ProcesoDisciplinar> consultaProcesoDisciplinarPorExpediente(String expediente) throws Exception {
		try {
			return procesoDisciplinarDao.consultaProcesoDisciplinarPorExpediente(expediente);
		} catch (Exception e) {
			throw new Exception(e);		 
		}
	}


	@Override
	public List<ProcesoDisciplinar> consultaProcesoDisciplinarPorInvestigado(Integer investigado) throws Exception {
		try {
			return procesoDisciplinarDao.consultaProcesoDisciplinarPorInvestigado(investigado);
		} catch (Exception e) {
			throw new Exception(e);		 
		}
	}


	@Override
	public List<ProcesoDisciplinar> findByIdProcesoDisciplinarIn(Integer[] ids) throws Exception {
		try {
			return procesoDisciplinarDao.findByIdProcesoDisciplinarIn(ids);
		} catch (Exception e) {
			throw new Exception(e);		 
		}
	}


}
