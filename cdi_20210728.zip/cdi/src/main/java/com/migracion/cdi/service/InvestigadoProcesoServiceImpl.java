package com.migracion.cdi.service;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.migracion.cdi.common.exception.MigracionException;
import com.migracion.cdi.dao.InvestigadoProcesoDao;
import com.migracion.cdi.model.InvestigadoProceso;

@Service
public class InvestigadoProcesoServiceImpl implements IInvestigadoProcesoService{
	
	@Autowired
	private InvestigadoProcesoDao investigadoProcesoDao;

	@Override
	public void guardar(InvestigadoProceso investigadoProceso) {
		investigadoProcesoDao.save(investigadoProceso);
		
	}
	
	@Override
	public List<InvestigadoProceso> consultarPorInvestigado(Integer investigado) throws Exception {
		try {
			return investigadoProcesoDao.consultarPorInvestigado(investigado);
		} catch (Exception e) {
			throw new Exception(e);		 
		}
	}
	
	@Override
	public List<InvestigadoProceso> consultarInvestigados() throws MigracionException {
		
		List<InvestigadoProceso> listInvestigado = new LinkedList<InvestigadoProceso>();
		
		InvestigadoProceso investigadoProceso = new InvestigadoProceso();
		investigadoProceso.setIdInvestigado(1);
		investigadoProceso.setNombreInvestigado("ALEXANDER TRES PALACIOS");
		listInvestigado.add(investigadoProceso);
		
		InvestigadoProceso investigadoProceso2 = new InvestigadoProceso();
		investigadoProceso2.setIdInvestigado(2);
		investigadoProceso2.setNombreInvestigado("ANDRÉS VILLA NUEVA");
		listInvestigado.add(investigadoProceso2);
		
		InvestigadoProceso investigadoProceso3 = new InvestigadoProceso();
		investigadoProceso3.setIdInvestigado(3);
		investigadoProceso3.setNombreInvestigado("FELIPE SANTODOMINGO");
		listInvestigado.add(investigadoProceso3);
		
		InvestigadoProceso investigadoProceso4 = new InvestigadoProceso();
		investigadoProceso4.setIdInvestigado(4);
		investigadoProceso4.setNombreInvestigado("PABLO LACOTURIE");
		listInvestigado.add(investigadoProceso4);
		
		return listInvestigado;
	}

}
