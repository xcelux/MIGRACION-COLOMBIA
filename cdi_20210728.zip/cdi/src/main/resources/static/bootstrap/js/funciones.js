function buscarDependencias(){
	
	   var regional = document.getElementById('idRegional').value;
		urlString = "http://localhost:8080/proceso/dependencias/"+regional;
		$.ajax({method: "GET", url: urlString})
			.done(function(response){
				//alert(JSON.stringify(response));
				$("#idSubtipologia").empty();
				
				response.forEach(function(valorLista){
					$("#idDependencia").append(new Option(valorLista.valor, valorLista.idTipoGeneral));
				})
				
			})
			.fail(function(){
				alert("Error conectando al servidor.");
			})
			.always(function(){
				//alert("Ejecutada")
			})
		;
		
	  }
	  
	  
	  
	  function buscarSubtipologias(){
	
	   var tipologia = document.getElementById('idTipologia').value;
		urlString = "http://localhost:8080/proceso/subtipologias/"+tipologia;
		$.ajax({method: "GET", url: urlString})
			.done(function(response){
				$("#idSubtipologia").empty();
				
				response.forEach(function(valorLista){
					$("#idSubtipologia").append(new Option(valorLista.nombre, valorLista.idSubtipologia));
				})
				
			})
			.fail(function(){
				alert("Error conectando al servidor.");
			})
			.always(function(){
				//alert("Ejecutada")
			})
		;
		
	  }