CREATE TABLE ProcesoDisciplinar (
	idProcesoDisciplinar NUMBER(7, 0) NOT NULL,
	numeroExpediente VARCHAR2(7) UNIQUE NOT NULL,
	idRadicadoOrfeo VARCHAR2(8) NOT NULL,
	fechaElaboracionFormato TIMESTAMP NOT NULL,
	fechaRecibido DATE NOT NULL,
	idTipologia NUMBER(3, 0) NOT NULL,
	idSubtipologia NUMBER(3, 0),
	hechos NVARCHAR2(1000),
	fechaHechos DATE,
	resumenHechos NVARCHAR2(500),
	idAbogado NUMBER(10, 0),
	nombreAbogado VARCHAR2(40),
	fechaAperturaIndagacion DATE,
	prorrogaInvestigacion NUMBER(3, 0),
	decision VARCHAR2(500),
	fechaDecision DATE,
	nombreQuejoso VARCHAR2(40),
	cedulaQuejoso VARCHAR2(12),
	generoQuejoso VARCHAR2(1),
	idTipoQuejoso INT,
	idNacionalidad NUMBER(3, 0),
	idAllegaPor NUMBER(3, 0),
	idEstadoDecision NUMBER(3, 0),
	idEtapaActual NUMBER(3, 0),
	idTipoProceso NUMBER(3, 0),
	idRegional NUMBER(3, 0),
	idDependencia NUMBER(3, 0),
	segundaInstancia VARCHAR2(300),
	devolucionSegundaInstancia VARCHAR2(300),
	fechaSiri VARCHAR2(300),
	estado NUMBER(1, 0),
	constraint PROCESODISCIPLINAR_PK PRIMARY KEY (idProcesoDisciplinar));

CREATE sequence ProcesoDisciplinar_idProcesoDisciplinar_seq;

CREATE trigger "BI_ProcesoDisciplinar_IDPROCESODISCIPLINAR"
  before insert on ProcesoDisciplinar
  for each row
begin
  select ProcesoDisciplinar_idProcesoDisciplinar_seq.nextval into :NEW.idProcesoDisciplinar from dual;
end;


/
CREATE TABLE Tipologia (
	idTipologia NUMBER(2,0) NOT NULL,
	nombre VARCHAR2(100) NOT NULL,
	descripcion VARCHAR2(500) NOT NULL,
	estado NUMBER(1,0) NOT NULL,
	constraint TIPOLOGIA_PK PRIMARY KEY (idTipologia));

CREATE sequence Tipologia_idTipologia_seq;

CREATE trigger "BI_Tipologia_IDTIPOLOGIA"
  before insert on Tipologia
  for each row
begin
  select Tipologia_idTipologia_seq.nextval into :NEW.idTipologia from dual;
end;

/
CREATE TABLE Subtipologia (
	idSubtipologia NUMBER(3, 0) NOT NULL,
	nombre VARCHAR2(50) NOT NULL,
	descripcion VARCHAR2(500) NOT NULL,
	idTipologia NUMBER(2, 0) UNIQUE NOT NULL,
	estado NUMBER(1,0) NOT NULL,
	constraint SUBTIPOLOGIA_PK PRIMARY KEY (idSubtipologia));

CREATE sequence Subtipologia_idSubTipologia_seq;

CREATE trigger "BI_Subtipologia_IDSUBTIPOLOGIA"
  before insert on Subtipologia
  for each row
begin
  select Subtipologia_idSubTipologia_seq.nextval into :NEW.idSubtipologia from dual;
end;

/
CREATE TABLE TipoGeneral (
	idTipoGeneral NUMBER(3,0) NOT NULL,
	codigoTipo VARCHAR2(20),
	idPadre NUMBER(4,0) NOT NULL,
	valor NVARCHAR2(200) NOT NULL,
	descripcion NVARCHAR2(500) NOT NULL,
	estado NUMBER(2,0) NOT NULL,
	constraint TipoGeneral_pk PRIMARY KEY (idTipoGeneral));

CREATE sequence TipoGeneral_idTipoGeneral_seq;

CREATE trigger "BI_TipoGeneral_IDTIPOGENERAL"
  before insert on TipoGeneral
  for each row
begin
  select TipoGeneral_idTipoGeneral_seq.nextval into :NEW.idTipoGeneral from dual;
end;

/
CREATE TABLE InvestigadoProceso (
	idProcesoDisciplinar NUMBER(7, 0) NOT NULL,
	IdInvestigado NUMBER(10, 0) NOT NULL,
	nombreInvestigado VARCHAR2(40) NOT NULL,
	constraint INVESTIGADOPROCESO_PK PRIMARY KEY (idProcesoDisciplinar,IdInvestigado));


/
ALTER TABLE ProcesoDisciplinar ADD CONSTRAINT ProcesoDisciplinar_IdTipologia FOREIGN KEY (idTipologia) REFERENCES TIPOLOGIA(idTipologia);
ALTER TABLE ProcesoDisciplinar ADD CONSTRAINT ProcesoDisciplinar_IdTipoQuejoso FOREIGN KEY (idTipoQuejoso) REFERENCES TipoGeneral(idTipoGeneral);
ALTER TABLE ProcesoDisciplinar ADD CONSTRAINT ProcesoDisciplinar_IdAllegaPor FOREIGN KEY (idAllegaPor) REFERENCES TipoGeneral(idTipoGeneral);
ALTER TABLE ProcesoDisciplinar ADD CONSTRAINT ProcesoDisciplinar_IdEstadoDecision FOREIGN KEY (idEstadoDecision) REFERENCES TipoGeneral(idTipoGeneral);
ALTER TABLE ProcesoDisciplinar ADD CONSTRAINT ProcesoDisciplinar_IdEtapaActual FOREIGN KEY (idEtapaActual) REFERENCES TipoGeneral(idTipoGeneral);
ALTER TABLE ProcesoDisciplinar ADD CONSTRAINT ProcesoDisciplinar_IdTipoProceso FOREIGN KEY (idTipoProceso) REFERENCES TipoGeneral(idTipoGeneral);
ALTER TABLE ProcesoDisciplinar ADD CONSTRAINT ProcesoDisciplinar_IdNacionalidad FOREIGN KEY (idNacionalidad) REFERENCES TipoGeneral(idTipoGeneral);
ALTER TABLE ProcesoDisciplinar ADD CONSTRAINT ProcesoDisciplinar_IdRegional FOREIGN KEY (idRegional) REFERENCES TipoGeneral(idTipoGeneral);
ALTER TABLE ProcesoDisciplinar ADD CONSTRAINT ProcesoDisciplinar_IdDependencia FOREIGN KEY (idDependencia) REFERENCES TipoGeneral(idTipoGeneral);


ALTER TABLE Subtipologia ADD CONSTRAINT Subtipologia_idSubtipologia FOREIGN KEY (idTipologia) REFERENCES TIPOLOGIA(idTipologia);

ALTER TABLE InvestigadoProceso ADD CONSTRAINT InvestigadoProceso_IdProcesoDisciplinar FOREIGN KEY (idProcesoDisciplinar) REFERENCES ProcesoDisciplinar(idProcesoDisciplinar);


COMMIT;



