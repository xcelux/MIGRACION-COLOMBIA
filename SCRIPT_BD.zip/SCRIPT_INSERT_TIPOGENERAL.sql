-- ==========================================================================
-- Author:		 Andrés Alberto Cortina Piña
-- email:        andrescort_4@hotmail.com
-- date:		 Mayo 28 de 2021
-- Description:	 Se inserta información paramétrica a la tabla TiipoGeneral
-- ==========================================================================

--SET SERVEROUTPUT ON;	

DECLARE

	v_fuenteDatos    			tipogeneral.idTipoGeneral%TYPE;
	v_estadoDecision 			tipogeneral.idTipoGeneral%TYPE;
	v_etapa          			tipogeneral.idTipoGeneral%TYPE;
	v_tipoProceso    			tipogeneral.idTipoGeneral%TYPE;
	v_nacionalidad   			tipogeneral.idTipoGeneral%TYPE;
	v_regional       			tipogeneral.idTipoGeneral%TYPE;
	v_dependencia    			tipogeneral.idTipoGeneral%TYPE;
	v_tipoQuejoso    			tipogeneral.idTipoGeneral%TYPE;
	
	v_dependencia_aeropuerto    tipogeneral.idTipoGeneral%TYPE;
	v_dependencia_amazonas      tipogeneral.idTipoGeneral%TYPE;
	v_dependencia_antioquia     tipogeneral.idTipoGeneral%TYPE;
	v_dependencia_atlantico     tipogeneral.idTipoGeneral%TYPE;
	v_dependencia_caribe        tipogeneral.idTipoGeneral%TYPE;
	v_dependencia_ejecafetero   tipogeneral.idTipoGeneral%TYPE;
	v_dependencia_guajira       tipogeneral.idTipoGeneral%TYPE;
	v_dependencia_narinio       tipogeneral.idTipoGeneral%TYPE;
	v_dependencia_nivelcentral  tipogeneral.idTipoGeneral%TYPE;
	v_dependencia_occidente     tipogeneral.idTipoGeneral%TYPE;
	v_dependencia_oriente       tipogeneral.idTipoGeneral%TYPE;
	v_dependencia_orinoquia     tipogeneral.idTipoGeneral%TYPE;
	v_dependencia_sanandres     tipogeneral.idTipoGeneral%TYPE;
  
BEGIN
  
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (0,'FuenteDatos','Tabla que almacena las diferentes fuentes de datos por las cuales puede llegar una queja',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (0,'EstadoDecision','Tabla que almacena los diferentes estados de decisión que puede tener un proceso disciplinar',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (0,'Etapa','Tabla que almacena las diferentes etapas de un proceso disciplinar',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (0,'TipoProceso','Tabla en la que se almacenan los tipos de procesos disciplinarios',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (0,'Nacionalidad','Tabla que almacena las diferentes nacionalidades de los sujetos disciplinarios',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (0,'Regional','Tabla en la que se almacenan las regionales de Migración Colombia',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (0,'Dependencia','Tabla en la que se almacenan las dependencias de Migración Colombia',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (0,'TipoQuejoso','Tabla en la que se almacenan los tipos quejosos que generan la creación de un proceso disciplinar',1);

	--DBMS_OUTPUT.PUT_LINE('SE REALIZO LA INSERCION DE LAS TABLAS PARAMETRICAS');


	select idTipoGeneral into v_fuenteDatos    from tipogeneral where idPadre = 0 and valor = 'FuenteDatos';
	select idTipoGeneral into v_estadoDecision from tipogeneral where idPadre = 0 and valor = 'EstadoDecision';
	select idTipoGeneral into v_etapa 		   from tipogeneral where idPadre = 0 and valor = 'Etapa';
	select idTipoGeneral into v_tipoProceso    from tipogeneral where idPadre = 0 and valor = 'TipoProceso';
	select idTipoGeneral into v_nacionalidad   from tipogeneral where idPadre = 0 and valor = 'Nacionalidad';
	select idTipoGeneral into v_regional       from tipogeneral where idPadre = 0 and valor = 'Regional';
	select idTipoGeneral into v_dependencia    from tipogeneral where idPadre = 0 and valor = 'Dependencia';
	select idTipoGeneral into v_tipoQuejoso    from tipogeneral where idPadre = 0 and valor = 'TipoQuejoso';
	
	--DBMS_OUTPUT.PUT_LINE('SE REALIZO LA ASIGNACION DE LOS IDS DE CADA TABLA A LAS VARIABLES');

	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_fuenteDatos,'CVAC+',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_fuenteDatos,'INFORME',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_fuenteDatos,'QUEJA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_fuenteDatos,'NOTICIA',' ',1);
	
	--DBMS_OUTPUT.PUT_LINE('SE REALIZO LA INSERCION DE LOS VALORES PARA LA TABLA FUENTE DE DATOS ');

	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_estadoDecision,'Evaluacion',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_estadoDecision,'Finalizado',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_estadoDecision,'Instrucción',' ',1);
	
	--DBMS_OUTPUT.PUT_LINE('SE REALIZO LA INSERCION DE LOS VALORES PARA LA TABLA ESTADO DECISION ');

	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_etapa,'Evaluar Noticia',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_etapa,'Noticia disciplinaria',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_etapa,'Indagación preliminar',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_etapa,'Investigación disciplinaria',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_etapa,'Cierre de investigación disciplinaria',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_etapa,'Pliego de cargos',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_etapa,'Descargos',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_etapa,'Pruebas',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_etapa,'Alegatos de conclusión',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_etapa,'Fallo de primera instancia',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_etapa,'Fallo de segunda instancia',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_etapa,'Citación a audiencia',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_etapa,'Lectura de citación',' ',1);
	
	--DBMS_OUTPUT.PUT_LINE('SE REALIZO LA INSERCION DE LOS VALORES PARA LA TABLA ETAPA ');


	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_tipoProceso,'ORDINARIO',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_tipoProceso,'VERBAL',' ',1);
	
	--DBMS_OUTPUT.PUT_LINE('SE REALIZO LA INSERCION DE LOS VALORES PARA LA TABLA TIPO PROCESO ');


	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ALBANESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ALEMANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ANDORRANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ANGOLESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ANTARTIDA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ANTIGUANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'APATRIDA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ARABE',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ARGELINA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ARGENTINO',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ARMENIA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'AUSTRALIANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'AUSTRIACA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'AZERBAIYANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'BAHAMEÑA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'BAHRENITA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'BARBADIANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'BELGA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'BELICEÑA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'BENGALESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'BENINESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'BETCHUANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'BHUTANESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'BIELORRUSA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'BIRMANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'BOINARENSE',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'BOLIVIANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'BOSNIA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'BRASILEÑO',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'BRITANICA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'BRITANICO',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'BRUENANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'BÚLGARA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'BURKINESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'BURUNDINESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'CABOVERDIANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'CAMBOYANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'CAMERUNENSE',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'CANADIENSE',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'CENTROAFRICANO',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'CHADIANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'CHECA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'CHILENA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'CHINA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'CHIPRIOTA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'CINGALESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'COLOMBIANO',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'COMORANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'CONGOLESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'COREANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'COSTARRICENSE',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'CROATA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'CUBANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'CURAZEÑO',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'DANESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'DESCONOCIDO',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'DOMINICA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'DOMINICANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ECUATOGUINEANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ECUATORIANO',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'EGIPCIA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ERITREA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ESLOVACA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ESLOVENIA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ESPAÑOLA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ESTADOUNIDENSE',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ESTONIA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ETIOPE',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'FIJIANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'FILIPINA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'FINLANDESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'FRANCES',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'GABONESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'GAMBIANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'GEORGIANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'GHANESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'GRANADINA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'GRIEGA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'GUATEMALTECA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'GUERNSEY',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'GUINEA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'GUINEANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'GUYANESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'HAITIANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'HOLANDÉS',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'HONDUREÑA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'HUNGARA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'INDIA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'INDONESIA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'IRANI',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'IRAQUI',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'IRLANDESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ISLA BOUVET',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ISLANDESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ISLAS COCOS',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ISLAS HEARD Y MCDONALD',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ISLAS MALVINAS',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ISLAS ULTRAMARINAS DE ESTADOS UNIDOS',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ISRAELI',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ITALIANO',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'JAMAIQUINA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'JAPONESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'JERSEY',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'JORDANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'KAZAQUI',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'KENYANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'KIRGUENSE',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'KIRIBATI',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'KOSOVO',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'KUWAITI',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'LAOSEANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'LEONESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'LESOTHA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'LETONA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'LIBANESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'LIBERIANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'LIECHTENSTEIN',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'LITUANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'LUXEMBURGUES',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'MACEDONIA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'MALAWI',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'MALAYA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'MALDIVIA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'MALGACHE',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'MALINESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'MALTESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'MARFILENSE',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'MARROQUI',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'MARSHALLINA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'MAURICIANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'MAURITANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'MEXICANO',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'MICRONESIA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'MOLDAVA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'MONEGASCA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'MONGOL',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'MONTENEGRO',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'MOZAMBIQUEÑA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'NAMIBIA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'NAURUANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'NEOZELANDESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'NEPALESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'NICARAGUENSE',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'NIGERIANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'NIGERINA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'NORCOREANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'NORFOLK',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'NORUEGA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'OMANI',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'PAKISTANI',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'PALAUENSE',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'PALESTINA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'PANAMEÑA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'PAPUES',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'PARAGUAYA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'PERUANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'POLACA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'PORTUGUESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'QATARIANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'REPUBLICA DEL CONGO',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'RUMANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'RUSA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'RWANDESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'SALOMONICA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'SALVADOREÑA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'SAMOANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'SANCRISTOBALENSE',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'SANMARINENSE',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'SANMARTINENSE',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'SANTA SEDE',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'SANTALUCENSE',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'SANTOTOMENSE',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'SANVICENTINA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'SAUDITA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'SENEGALESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'SERBIA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'SEYCHELLESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'SINGAPURIANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'SIRIA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'SOMALI',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'SUDAFRICANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'SUDANESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'SUDSUDANES',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'SUECA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'SUIZA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'SURGEORGIANO',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'SURINAMESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'SWAZI',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'TAILANDESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'TAIWANESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'TANZANIA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'TAYIKISTANI',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'TOGOLESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'TONGANESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'TRINITARIA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'TUNECINA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'TURCA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'TURCOMANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'TUVALUANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'UCRANIANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'UGANDESA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'URUGUAYO',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'UZBEQUI',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'VANUATUENSE',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'VENEZOLANO',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'VIETNAMITA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'YEMENITA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ZAMBIANA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_nacionalidad,'ZIMBABWUANA',' ',1);

	
	--DBMS_OUTPUT.PUT_LINE('SE REALIZO LA INSERCION DE LOS VALORES PARA LA TABLA NACIONALIDAD ');
	
	
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_regional,'AEROPUERTO EL DORADO',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_regional,'AMAZONAS',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_regional,'ANTIOQUIA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_regional,'ATLANTICO',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_regional,'CARIBE',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_regional,'EJE CAFETERO',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_regional,'GUAJIRA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_regional,'NARIÑO',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_regional,'NIVEL CENTRAL',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_regional,'OCCIDENTE',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_regional,'ORIENTE',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_regional,'ORINOQUIA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_regional,'SAN ANDRES',' ',1);
	
	--DBMS_OUTPUT.PUT_LINE('SE REALIZO LA INSERCION DE LOS VALORES PARA LA TABLA REGIONAL ');
	
	select idTipoGeneral into v_dependencia_aeropuerto    from tipogeneral where valor = 'AEROPUERTO EL DORADO';
	select idTipoGeneral into v_dependencia_amazonas 	  from tipogeneral where valor = 'AMAZONAS';
	select idTipoGeneral into v_dependencia_antioquia 	  from tipogeneral where valor = 'ANTIOQUIA';
	select idTipoGeneral into v_dependencia_atlantico     from tipogeneral where valor = 'ATLANTICO';
	select idTipoGeneral into v_dependencia_caribe  	  from tipogeneral where valor = 'CARIBE';
	select idTipoGeneral into v_dependencia_ejecafetero   from tipogeneral where valor = 'EJE CAFETERO';
	select idTipoGeneral into v_dependencia_guajira    	  from tipogeneral where valor = 'GUAJIRA';
	select idTipoGeneral into v_dependencia_narinio       from tipogeneral where valor = 'NARIÑO';
	select idTipoGeneral into v_dependencia_nivelcentral  from tipogeneral where valor = 'NIVEL CENTRAL';
	select idTipoGeneral into v_dependencia_occidente     from tipogeneral where valor = 'OCCIDENTE';
	select idTipoGeneral into v_dependencia_oriente       from tipogeneral where valor = 'ORIENTE';
	select idTipoGeneral into v_dependencia_orinoquia     from tipogeneral where valor = 'ORINOQUIA';
	select idTipoGeneral into v_dependencia_sanandres     from tipogeneral where valor = 'SAN ANDRES';
	
	
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_aeropuerto,'AEROPUERTO INTERNACIONAL EL DORADO PCM','PCM-AEROPUERTO INTERNACIONAL EL DORADO-AÉREO',1);

	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_amazonas,'AEROPUERTO INTERNACIONAL ALFREDO VÁSQUEZ COBO PCM','PCM-AEROPUERTO INTERNACIONAL ALFREDO VÁSQUEZ COBO-AÉREO',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_amazonas,'LETICIA CFSM','CFSM-LETICIA',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_amazonas,'RÍO AMAZONAS PCM ','PCM-RÍO AMAZONAS-FLUVIAL',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_antioquia,'AEROPUERTO ENRIQUE OLAYA HERRERA PCM','PCM-AEROPUERTO ENRIQUE OLAYA HERRERA-AÉREO',1);

	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_antioquia,'AEROPUERTO INTERNACIONAL JOSÉ MARÍA CÓRDOVA PCM','PCM-AEROPUERTO INTERNACIONAL JOSÉ MARÍA CÓRDOVA-AÉREO',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_antioquia,'BAHÍA SOLANO PCM','PCM-BAHÍA SOLANO-MARÍTIMO',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_antioquia,'CAPURGANÁ PCM','PCM-CAPURGANÁ-MARÍTIMO',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_antioquia,'JURADÓ PCM','PCM-JURADÓ-MARÍTIMO',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_antioquia,'MEDELLÍN CFSM','CFSM-MEDELLÍN',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_antioquia,'QUIBDÓ CFSM','CFSM-QUIBDÓ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_antioquia,'TURBO PCM','PCM-TURBO-MARÍTIMO',1);

	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_atlantico,'AEROPUERTO INTERNACIONAL ERNESTO CORTISSOZ PCM','AEROPUERTO INTERNACIONAL ERNESTO CORTISSOZ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_atlantico,'AEROPUERTO INTERNACIONAL SIMÓN BOLÍVAR PCM','AEROPUERTO INTERNACIONAL SIMÓN BOLÍVAR',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_atlantico,'BARRANQUILLA CFSM','CFSM-BARRANQUILLA',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_atlantico,'BARRANQUILLA PCM ','PCM-BARRANQUILLA',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_atlantico,'SANTA MARTA CFSM','CFSM-SANTA MARTA',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_atlantico,'SANTA MARTA PCM','PCM-SANTA MARTA',1);

	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_caribe,'AEROPUERTO INTERNACIONAL RAFAEL NÚÑEZ PCM','AEROPUERTO INTERNACIONAL RAFAEL NÚÑEZ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_caribe,'CARTAGENA CFSM','CFSM-CARTAGENA',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_caribe,'CARTAGENA PCM','PCM-CARTAGENA',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_caribe,'COVEÑAS PCM','COVEÑAS',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_caribe,'MONTERÍA CFSM','MONTERÍA',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_caribe,'SINCELEJO CFSM','SINCELEJO',1);

	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_ejecafetero,'AEROPUERTO INTERNACIONAL EL EDÉN PCM','PCM-AEROPUERTO INTERNACIONAL EL EDÉN-AÉREO',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_ejecafetero,'AEROPUERTO INTERNACIONAL MATECAÑA PCM','PCM-AEROPUERTO INTERNACIONAL MATECAÑA-AÉREO',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_ejecafetero,'ARMENIA CFSM','CFSM-ARMENIA',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_ejecafetero,'MANIZALES CFSM','CFSM-MANIZALES',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_ejecafetero,'PEREIRA CFSM','CFSM-PEREIRA',1);

	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_guajira,'AEROPUERTO INTERNACIONAL ALMIRANTE PADILLA PCM','PCM-AEROPUERTO INTERNACIONAL ALMIRANTE PADILLA-AÉREO',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_guajira,'MAICAO CFSM','CFSM-MAICAO',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_guajira,'PARAGUACHÓN PCM','PCM-PARAGUACHÓN-TERRESTRE',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_guajira,'PUERTO NUEVO PCM','PCM-PUERTO NUEVO-MARÍTIMO',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_guajira,'RIOHACHA CFSM','CFSM-RIOHACHA',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_guajira,'VALLEDUPAR CFSM','CFSM-VALLEDUPAR',1);

	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_narinio,'CHILES PCM','PCM-CHILES-TERRESTRE',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_narinio,'PASTO CFSM','CFSM-PASTO',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_narinio,'PUERTO LEGUÍZAMO PCM','PCM-PUERTO LEGUÍZAMO-FLUVIAL',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_narinio,'RUMICHACA PCM','PCM-RUMICHACA-TERRESTRE',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_narinio,'SAN MIGUEL PCM','PCM-SAN MIGUEL-TERRESTRE',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_narinio,'TUMACO PCM','PCM-TUMACO-MARÍTIMO',1);

	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_nivelcentral,'TALENTO HUMANO',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_nivelcentral,'ADMINISTRATIVA',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_nivelcentral,'FINANCIERA',' ',1);

	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_occidente,'AEROPUERTO INTERNACIONAL ALFONSO BONILLA ARAGÓN PCM','PCM-AEROPUERTO INTERNACIONAL ALFONSO BONILLA ARAGÓN-AÉREO',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_occidente,'BUENAVENTURA PCM','PCM-BUENAVENTURA-MARÍTIMO',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_occidente,'CALI CFSM','CFSM-CALI',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_occidente,'POPAYÁN CFSM','CFSM-POPAYÁN',1);

	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_oriente,'AEROPUERTO INTERNACIONAL CAMILO DAZA PCM','PCM-AEROPUERTO INTERNACIONAL CAMILO DAZA-AÉREO',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_oriente,'AEROPUERTO INTERNACIONAL PALONEGRO PCM','PCM-AEROPUERTO INTERNACIONAL PALONEGRO-AÉREO',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_oriente,'BUCARAMANGA CFSM','CFSM-BUCARAMANGA',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_oriente,'CÚCUTA CFSM','CFSM-CÚCUTA',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_oriente,'FRANCISCO DE PAULA SANTANDER PCM','PCM-FRANCISCO DE PAULA SANTANDER-TERRESTRE',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_oriente,'PUENTE INTERNACIONAL LA UNIDAD PCM','PCM-PUENTE INTERNACIONAL LA UNIDAD-TERRESTRE',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_oriente,'PUENTE INTERNACIONAL LA UNIÓN PCM','PCM-PUENTE INTERNACIONAL LA UNIÓN-TERRESTRE',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_oriente,'SIMÓN BOLÍVAR PCM','PCM-SIMÓN BOLÍVAR-TERRESTRE',1);

	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_orinoquia,'ARAUCA CFSM ','CFSM-ARAUCA',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_orinoquia,'JOSÉ ANTONIO PÁEZ PCM','PCM-JOSÉ ANTONIO PÁEZ-TERRESTRE',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_orinoquia,'PUERTO CARREÑO PCM','PCM-PUERTO CARREÑO-FLUVIAL',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_orinoquia,'PUERTO INÍRIDA PCM','PCM-PUERTO INÍRIDA-FLUVIAL',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_orinoquia,'VILLAVICENCIO CFSM','CFSM-VILLAVICENCIO',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_orinoquia,'YOPAL CFSM','CFSM-YOPAL',1);

	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_sanandres,'AEROPUERTO INTERNACIONAL GUSTAVO ROJAS PINILLA PCM','AEROPUERTO INTERNACIONAL GUSTAVO ROJAS PINILLA',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_sanandres,'PROVIDENCIA PCM','PROVIDENCIA',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_sanandres,'SAN ANDRÉS CFSM ','CFSM-SAN ANDRÉS',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_dependencia_sanandres,'SAN ANDRÉS PCM','PCM-SAN ANDRÉS',1);


		
	--DBMS_OUTPUT.PUT_LINE('SE REALIZO LA INSERCION DE LOS VALORES PARA LA TABLA DEPENDENCIA ');

	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_tipoQuejoso,'ANÓNIMO',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_tipoQuejoso,'CIUDADANO',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_tipoQuejoso,'FUNCIONARIO',' ',1);
	insert into tipogeneral (idPadre,valor,descripcion,estado) values (v_tipoQuejoso,'OTRO',' ',1);

	--DBMS_OUTPUT.PUT_LINE('SE REALIZO LA INSERCION DE LOS VALORES PARA LA TABLA TIPO QUEJOSO ');


END;