package com.migracion.cdi.service;

import java.util.List;

import com.migracion.cdi.model.TipoGeneral;

public interface ITipoGeneralService {
	
	//public List<TipoGeneral> consultaListaTiposGenerales(String valor) throws Exception;
	public TipoGeneral buscarTipoGeneralesPorValor(String valor) throws Exception;
	public List<TipoGeneral> buscarTiposGeneralesPorValor(String valor) throws Exception;
	public List<TipoGeneral> buscarTiposGeneralesPorIdPadre(Integer idPadre) throws Exception;	
	/*public List<TipoGeneral> buscarTiposGeneralesPorCodigoTipo(String codigoTipo) throws Exception;
	public TipoGeneral buscarTipoGeneralesPorCodigoTipo(String codigoTipo) throws Exception;
	public List<Integer> buscarIdTipoGeneralesPorCodigosTipo(String... paramVarArgs) throws Exception;*/

}
