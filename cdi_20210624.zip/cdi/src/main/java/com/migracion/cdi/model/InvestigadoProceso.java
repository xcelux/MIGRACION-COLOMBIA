package com.migracion.cdi.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@IdClass(InvestigadoProcesoPK.class)
@Table(name="InvestigadoProceso")
public class InvestigadoProceso implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	private Integer idProcesoDisciplinar;
	
	@Id
	private Integer idInvestigado;
	
	private String nombreInvestigado;
	
	

	public Integer getIdProcesoDisciplinar() {
		return idProcesoDisciplinar;
	}

	public void setIdProcesoDisciplinar(Integer idProcesoDisciplinar) {
		this.idProcesoDisciplinar = idProcesoDisciplinar;
	}

	public Integer getIdInvestigado() {
		return idInvestigado;
	}

	public void setIdInvestigado(Integer idInvestigado) {
		this.idInvestigado = idInvestigado;
	}

	public String getNombreInvestigado() {
		return nombreInvestigado;
	}

	public void setNombreInvestigado(String nombreInvestigado) {
		this.nombreInvestigado = nombreInvestigado;
	}
	
	

}
