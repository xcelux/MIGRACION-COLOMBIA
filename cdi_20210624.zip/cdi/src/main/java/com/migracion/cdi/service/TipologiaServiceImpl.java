package com.migracion.cdi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.migracion.cdi.dao.TipologiaDao;
import com.migracion.cdi.model.Tipologia;

@Service
public class TipologiaServiceImpl implements ITipologiaService{
	
	@Autowired
	private TipologiaDao tipologiaDao;
	
	@Override
	@Transactional(readOnly = true)
	public List<Tipologia> consultaListaTipologias() throws Exception {
		try {
			return tipologiaDao.consultaListaTipologias();
		} catch (Exception e) {
			throw new Exception(e);		 
		}
	}

}
