package com.migracion.cdi.service;

import com.migracion.cdi.model.InvestigadoProceso;

public interface IInvestigadoProcesoService {

	public void guardar(InvestigadoProceso investigadoProceso);
}
