package com.migracion.cdi.common.exception;

public class MigracionException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MigracionException(String message) {
        super(message);
    }

	
	public MigracionException(String message, Throwable cause) {
		super(message, cause);
		
	}
	
	public MigracionException(Throwable cause) {
		super(cause);
		
	}

}
