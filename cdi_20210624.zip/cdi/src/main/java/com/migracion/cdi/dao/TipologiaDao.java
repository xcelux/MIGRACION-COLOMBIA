package com.migracion.cdi.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.migracion.cdi.model.Tipologia;

@Repository
public interface TipologiaDao extends CrudRepository<Tipologia, Integer>{
	
	@Query("SELECT t FROM Tipologia t WHERE t.estado = 1")
	public List<Tipologia> consultaListaTipologias();

}
