package com.migracion.cdi.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.migracion.cdi.model.Subtipologia;
import com.migracion.cdi.model.TipoGeneral;

@Repository
public interface SubtipologiaDao extends CrudRepository<Subtipologia, Integer>{
	
	@Query("SELECT s FROM Subtipologia s WHERE s.estado = 1")
	public List<Subtipologia> consultaListaSubtipologias();
	
	@Query("SELECT s FROM Subtipologia s WHERE s.idTipologia.idTipologia = :idTipologia order by s.nombre")
	public List<Subtipologia> buscarSubtipologiasPorIdTipologia(Integer idTipologia);

}