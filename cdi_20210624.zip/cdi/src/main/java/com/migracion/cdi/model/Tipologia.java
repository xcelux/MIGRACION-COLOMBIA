package com.migracion.cdi.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Tipologia")
public class Tipologia implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="Tipologia_idTipologia_seq")
	@SequenceGenerator(name="Tipologia_idTipologia_seq", sequenceName="Tipologia_idTipologia_seq", allocationSize=1)
	private Integer idTipologia;
	
	private String nombre;
	private String descripcion;
	private Integer estado;
	
	
	public Integer getIdTipologia() {
		return idTipologia;
	}
	public void setIdTipologia(Integer idTipologia) {
		this.idTipologia = idTipologia;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public Integer getEstado() {
		return estado;
	}
	public void setEstado(Integer estado) {
		this.estado = estado;
	}
	
	

}
