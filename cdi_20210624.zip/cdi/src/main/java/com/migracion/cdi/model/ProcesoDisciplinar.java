package com.migracion.cdi.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name="ProcesoDisciplinar")
public class ProcesoDisciplinar implements Serializable{
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ProcesoDisciplinar_idProcesoDisciplinar_seq")
	@SequenceGenerator(name="ProcesoDisciplinar_idProcesoDisciplinar_seq", sequenceName="ProcesoDisciplinar_idProcesoDisciplinar_seq", allocationSize=1)
	private Integer idProcesoDisciplinar;
	
	private Date  fechaRecibido;
	private Date  fechaElaboracionFormato;
	private String  numeroExpediente;
	private String  idRadicadoOrfeo;
	private String  hechos;
	private Date    fechaHechos;
	private Integer estado;
	private Integer idAbogado;
	private Date  fechaAperturaIndagacion;
	private Integer prorrogaInvestigacion;
	private String  decision;
	private Date  fechaDecision;
	private Integer idSubtipologia;
	
	@JoinColumn(name = "idTipologia", referencedColumnName = "idTipologia")
	@OneToOne(optional = false)
	private Tipologia idTipologia; 
	
	public Integer getIdSubtipologia() {
		return idSubtipologia;
	}
	public void setIdSubtipologia(Integer idSubtipologia) {
		this.idSubtipologia = idSubtipologia;
	}
	@JoinColumn(name = "idRegional", referencedColumnName = "idTipoGeneral")
	@OneToOne(optional = false)
	private TipoGeneral idRegional; 
	
	@JoinColumn(name = "idDependencia", referencedColumnName = "idTipoGeneral")
	@OneToOne(optional = false)
	private TipoGeneral idDependencia;
	
	@JoinColumn(name = "idAllegaPor", referencedColumnName = "idTipoGeneral")
	@OneToOne(optional = false)
	private TipoGeneral idAllegaPor;
	
	@JoinColumn(name = "idEstadoDecision", referencedColumnName = "idTipoGeneral")
	@OneToOne(optional = true)
	private TipoGeneral idEstadoDecision;
	
	@JoinColumn(name = "idEtapaActual", referencedColumnName = "idTipoGeneral")
	@OneToOne(optional = true)
	private TipoGeneral idEtapaActual;
	
	@JoinColumn(name = "idTipoProceso", referencedColumnName = "idTipoGeneral")
	@OneToOne(optional = true)
	private TipoGeneral idTipoProceso;
	
	@JoinColumn(name = "idNacionalidad", referencedColumnName = "idTipoGeneral")
	@OneToOne(optional = true)
	private TipoGeneral idNacionalidad;
	
	@JoinColumn(name = "idTipoQuejoso", referencedColumnName = "idTipoGeneral")
	@OneToOne(optional = true)
	private TipoGeneral idTipoQuejoso;
	

	private String  segundaInstancia;
	private String  devolucionSegundaInstancia;
	private Date  fechaSiri;
	private String nombreAbogado;
	private String nombreQuejoso;
	private String cedulaQuejoso;
	private String generoQuejoso;
	
	@OneToMany(cascade = {CascadeType.ALL}, mappedBy = "idProcesoDisciplinar")
	private List<InvestigadoProceso> listaInvestigados;
	
	
	public Integer getIdProcesoDisciplinar() {
		return idProcesoDisciplinar;
	}
	public void setIdProcesoDisciplinar(Integer idProcesoDisciplinar) {
		this.idProcesoDisciplinar = idProcesoDisciplinar;
	}
	public Date getFechaRecibido() {
		return fechaRecibido;
	}
	public void setFechaRecibido(Date fechaRecibido) {
		this.fechaRecibido = fechaRecibido;
	}
	public Date getFechaElaboracionFormato() {
		return fechaElaboracionFormato;
	}
	public void setFechaElaboracionFormato(Date fechaElaboracionFormato) {
		this.fechaElaboracionFormato = fechaElaboracionFormato;
	}
	public String getNumeroExpediente() {
		return numeroExpediente;
	}
	public void setNumeroExpediente(String numeroExpediente) {
		this.numeroExpediente = numeroExpediente;
	}
	public String getIdRadicadoOrfeo() {
		return idRadicadoOrfeo;
	}
	public void setIdRadicadoOrfeo(String idRadicadoOrfeo) {
		this.idRadicadoOrfeo = idRadicadoOrfeo;
	}
	public String getHechos() {
		return hechos;
	}
	public void setHechos(String hechos) {
		this.hechos = hechos;
	}
	public Date getFechaHechos() {
		return fechaHechos;
	}
	public void setFechaHechos(Date fechaHechos) {
		this.fechaHechos = fechaHechos;
	}
	public Tipologia getIdTipologia() {
		return idTipologia;
	}
	public void setIdTipologia(Tipologia idTipologia) {
		this.idTipologia = idTipologia;
	}
	public Integer getEstado() {
		return estado;
	}
	public void setEstado(Integer estado) {
		this.estado = estado;
	}
	public Integer getIdAbogado() {
		return idAbogado;
	}
	public void setIdAbogado(Integer idAbogado) {
		this.idAbogado = idAbogado;
	}
	public Date getFechaAperturaIndagacion() {
		return fechaAperturaIndagacion;
	}
	public void setFechaAperturaIndagacion(Date fechaAperturaIndagacion) {
		this.fechaAperturaIndagacion = fechaAperturaIndagacion;
	}
	public Integer getProrrogaInvestigacion() {
		return prorrogaInvestigacion;
	}
	public void setProrrogaInvestigacion(Integer prorrogaInvestigacion) {
		this.prorrogaInvestigacion = prorrogaInvestigacion;
	}
	public String getDecision() {
		return decision;
	}
	public void setDecision(String decision) {
		this.decision = decision;
	}
	public Date getFechaDecision() {
		return fechaDecision;
	}
	public void setFechaDecision(Date fechaDecision) {
		this.fechaDecision = fechaDecision;
	}
	public TipoGeneral getIdRegional() {
		return idRegional;
	}
	public void setIdRegional(TipoGeneral idRegional) {
		this.idRegional = idRegional;
	}
	public TipoGeneral getIdDependencia() {
		return idDependencia;
	}
	public void setIdDependencia(TipoGeneral idDependencia) {
		this.idDependencia = idDependencia;
	}
	public TipoGeneral getIdAllegaPor() {
		return idAllegaPor;
	}
	public void setIdAllegaPor(TipoGeneral idAllegaPor) {
		this.idAllegaPor = idAllegaPor;
	}
	
	public TipoGeneral getIdEstadoDecision() {
		return idEstadoDecision;
	}
	public void setIdEstadoDecision(TipoGeneral idEstadoDecision) {
		this.idEstadoDecision = idEstadoDecision;
	}
	public TipoGeneral getIdEtapaActual() {
		return idEtapaActual;
	}
	public void setIdEtapaActual(TipoGeneral idEtapaActual) {
		this.idEtapaActual = idEtapaActual;
	}
	public TipoGeneral getIdTipoProceso() {
		return idTipoProceso;
	}
	public void setIdTipoProceso(TipoGeneral idTipoProceso) {
		this.idTipoProceso = idTipoProceso;
	}
	public TipoGeneral getIdNacionalidad() {
		return idNacionalidad;
	}
	public void setIdNacionalidad(TipoGeneral idNacionalidad) {
		this.idNacionalidad = idNacionalidad;
	}
	public String getSegundaInstancia() {
		return segundaInstancia;
	}
	public void setSegundaInstancia(String segundaInstancia) {
		this.segundaInstancia = segundaInstancia;
	}
	public String getDevolucionSegundaInstancia() {
		return devolucionSegundaInstancia;
	}
	public void setDevolucionSegundaInstancia(String devolucionSegundaInstancia) {
		this.devolucionSegundaInstancia = devolucionSegundaInstancia;
	}
	public Date getFechaSiri() {
		return fechaSiri;
	}
	public void setFechaSiri(Date fechaSiri) {
		this.fechaSiri = fechaSiri;
	}
	public String getNombreAbogado() {
		return nombreAbogado;
	}
	public void setNombreAbogado(String nombreAbogado) {
		this.nombreAbogado = nombreAbogado;
	}
	public String getNombreQuejoso() {
		return nombreQuejoso;
	}
	public void setNombreQuejoso(String nombreQuejoso) {
		this.nombreQuejoso = nombreQuejoso;
	}
	public TipoGeneral getIdTipoQuejoso() {
		return idTipoQuejoso;
	}
	public void setIdTipoQuejoso(TipoGeneral idTipoQuejoso) {
		this.idTipoQuejoso = idTipoQuejoso;
	}
	public String getCedulaQuejoso() {
		return cedulaQuejoso;
	}
	public void setCedulaQuejoso(String cedulaQuejoso) {
		this.cedulaQuejoso = cedulaQuejoso;
	}
	public List<InvestigadoProceso> getListaInvestigados() {
		return listaInvestigados;
	}
	public void setListaInvestigados(List<InvestigadoProceso> listaInvestigados) {
		this.listaInvestigados = listaInvestigados;
	}
	public String getGeneroQuejoso() {
		return generoQuejoso;
	}
	public void setGeneroQuejoso(String generoQuejoso) {
		this.generoQuejoso = generoQuejoso;
	}
	
	
	
}
