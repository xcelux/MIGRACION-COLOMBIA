package com.migracion.cdi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.migracion.cdi.dao.SubtipologiaDao;
import com.migracion.cdi.model.Subtipologia;

@Service
public class SubtipologiaServiceImpl implements ISubtipologiaService{
	
	@Autowired
	private SubtipologiaDao subtipologiaDao;
	
	@Override
	@Transactional(readOnly = true)
	public List<Subtipologia> consultaListaSubtipologias() throws Exception {
		try {
			return subtipologiaDao.consultaListaSubtipologias();
		} catch (Exception e) {
			throw new Exception(e);		 
		}
	}

	@Override
	public List<Subtipologia> buscarSubtipologiasPorIdTipologia(Integer idTipologia) throws Exception {
		try {
			return subtipologiaDao.buscarSubtipologiasPorIdTipologia(idTipologia);
		} catch (Exception e) {
			throw new Exception(e);		 
		}
	}

}
