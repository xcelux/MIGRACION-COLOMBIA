package com.migracion.cdi.common;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import com.migracion.cdi.model.InvestigadoProceso;

public class CDIUtil {
	
	
	public Date adicionarAnio(Date fecha) {
		
		return new Date();
	}
	
	public static String DateToString(Date fecha) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
		String fechaCadena = sdf.format(fecha);
		return fechaCadena;
	}
	
	public String anioActual() {
		Date fechaActual = new Date();
        SimpleDateFormat getYearFormat = new SimpleDateFormat("yyyy");
        String anioActual = getYearFormat.format(fechaActual).substring(2);
        return anioActual;
	}
	
	public String generarCodidgoExpediente(String codExpedienteActual) {
        String codExpedienteNuevo="";
        
            String anioUltimoExpediente = codExpedienteActual.substring(5);
            String anioActual = this.anioActual();

            if(!anioUltimoExpediente.equals(anioActual)){
                codExpedienteNuevo = "0001/"+anioActual;
            }else{

                int contador = 0;
                while(codExpedienteActual.substring(contador,contador+1).equals("0")){
                    contador++;
                }

                String numeroSinCeros = codExpedienteActual.substring(contador,4);
                Integer numeroConsecutivo = (Integer.parseInt(numeroSinCeros))+1;
                int numeroDigitos = 4 - numeroConsecutivo.toString().length();

                String nuevoConsecutivo = "";
                while(nuevoConsecutivo.length()<numeroDigitos){
                    nuevoConsecutivo = nuevoConsecutivo + "0";
                }
                nuevoConsecutivo = nuevoConsecutivo + numeroConsecutivo;
                codExpedienteNuevo = nuevoConsecutivo+"/"+anioUltimoExpediente;

            }

		return codExpedienteNuevo;
	}
	
	
	public List<InvestigadoProceso> obtenerListaInvestigadosPorId(List<InvestigadoProceso> listaFuncionarios, Integer[] investigados, Integer idProcesoDisciplinar) {
		
		List<InvestigadoProceso> listaInvestigados = new LinkedList<InvestigadoProceso>();
		InvestigadoProceso investigadoProceso;
		
		int contador = 0;
		for(int i=0;i<listaFuncionarios.size();i++) {
			
			if( contador < investigados.length  && listaFuncionarios.get(i).getIdInvestigado()==investigados[contador]) {
				investigadoProceso = new InvestigadoProceso();
				investigadoProceso.setIdProcesoDisciplinar(idProcesoDisciplinar);
				investigadoProceso.setIdInvestigado(listaFuncionarios.get(i).getIdInvestigado());
				investigadoProceso.setNombreInvestigado(listaFuncionarios.get(i).getNombreInvestigado());
				
				listaInvestigados.add(investigadoProceso);
				contador++;
			}
			
		}
		
		return listaInvestigados;
		
	}
	

}
