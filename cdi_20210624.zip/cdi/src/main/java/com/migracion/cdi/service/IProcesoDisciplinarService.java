package com.migracion.cdi.service;


import com.migracion.cdi.model.ProcesoDisciplinar;
import java.util.List;

public interface IProcesoDisciplinarService {
	
	public void guardar(ProcesoDisciplinar procesoDisciplinar);
	public ProcesoDisciplinar consultaProcesoDisciplinarPorId(Integer id) throws Exception;
	public String buscarUltimoCodigoExpediente() throws Exception;
	public Integer buscarUltimoProcesoDisciplinar()throws Exception;
	
	public List<ProcesoDisciplinar> consultaProcesoDisciplinarPorExpediente(String expediente) throws Exception;
	public List<ProcesoDisciplinar> consultaProcesoDisciplinarPorInvestigado(Integer investigado) throws Exception;
}
