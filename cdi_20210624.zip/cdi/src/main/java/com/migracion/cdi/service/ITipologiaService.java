package com.migracion.cdi.service;

import java.util.List;

import com.migracion.cdi.model.Tipologia;

public interface ITipologiaService {
	
	public List<Tipologia> consultaListaTipologias() throws Exception;

}
