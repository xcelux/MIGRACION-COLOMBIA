package com.migracion.cdi;

import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.web.client.RestTemplate;

import com.migracion.cdi.webservice.common.SoapBody;
import com.migracion.cdi.webservice.common.SoapEnvelop;
import com.migracion.cdi.webservice.orfeo.consultarradicado.ConsultarRadicado;

public class PruebaConcepto {

	public static void main(String[] args) throws JAXBException {
		RestTemplate restTemplate = new RestTemplate();
		SoapEnvelop soapEnv = new SoapEnvelop();
		SoapBody soapBody = new SoapBody();
		ConsultarRadicado consultar = new ConsultarRadicado();
		consultar.setRadicado("2");
		soapBody.setConsultarRadicado(consultar);
		soapEnv.setSoapBody(soapBody);
		HttpEntity<?> httpEntity = new HttpEntity<SoapEnvelop>(soapEnv);
		String respuesta = restTemplate
				.exchange("http://orfeoprueba/webServices/servidor.php", HttpMethod.POST, httpEntity, String.class)
				.getBody();
		System.out.println("Respuesta " + respuesta);

	}

	public void conMarshall() throws JAXBException {
		RestTemplate restTemplate = new RestTemplate();
		HttpEntity<?> httpEntity = new HttpEntity<String>("<soapenv:Envelope xmlns:nus=\"webServices/nusoap\">\n"
				+ "   <soapenv:Header/>\n" + "   <soapenv:Body>\n" + "      <nus:consultarRadicado>\n"
				+ "         <radicado xsi:type=\"xsd:string\">2</radicado>\n" + "      </nus:consultarRadicado>\n"
				+ "   </soapenv:Body>\n" + "</soapenv:Envelope>");

		String respuesta = restTemplate
				.exchange("http://orfeoprueba/webServices/servidor.php", HttpMethod.POST, httpEntity, String.class)
				.getBody();

		System.out.println(respuesta);

		JAXBContext jaxbContext = JAXBContext.newInstance(SoapEnvelop.class);

		Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
		jaxbMarshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);

		StringWriter sw = new StringWriter();
		// jaxbMarshaller.marshal(soapEnv, sw);
		String xmlString = sw.toString();

		System.out.println(xmlString);

	}
}
