package com.migracion.cdi;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.migracion.cdi.model.ProcesoDisciplinar;
import com.migracion.cdi.service.IProcesoDisciplinarService;

@RunWith(SpringRunner.class)
@ActiveProfiles("local")
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureWebTestClient
class CdiApplicationTests {
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private IProcesoDisciplinarService serviceProcesoDisciplinar;

	@Test
	void contextLoads() {
		HttpEntity<?> httpEntity = new HttpEntity<String>("<soapenv:Envelope xmlns:nus=\"webServices/nusoap\">\n"
				+ "   <soapenv:Header/>\n"
				+ "   <soapenv:Body>\n"
				+ "      <nus:consultarRadicado>\n"
				+ "         <radicado xsi:type=\"xsd:string\">2</radicado>\n"
				+ "      </nus:consultarRadicado>\n"
				+ "   </soapenv:Body>\n"
				+ "</soapenv:Envelope>");

				String respuesta= restTemplate.exchange("http://orfeoprueba/webServices/servidor.php", HttpMethod.POST,
						httpEntity, String.class).getBody();
				
				System.out.println(respuesta);
	}
	
	public void guardar() {
		
		ProcesoDisciplinar procesoDisciplinar = new ProcesoDisciplinar();
		procesoDisciplinar.setDecision("Decision");
		
		serviceProcesoDisciplinar.guardar(procesoDisciplinar);
		
		System.out.println("Prueba test....");

	}

}
