package com.migracion.cdi.webservice.common;

import com.migracion.cdi.webservice.orfeo.consultarradicado.ConsultarRadicado;

public class SoapBody {	
	private ConsultarRadicado consultarRadicadoRequest;

	public ConsultarRadicado getConsultarRadicado() {
		return consultarRadicadoRequest;
	}

	public void setConsultarRadicado(ConsultarRadicado consultarRadicadoRequest) {
		this.consultarRadicadoRequest = consultarRadicadoRequest;
	}
	
	
}