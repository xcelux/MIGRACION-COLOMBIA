package com.migracion.cdi.webservice.orfeo.consultarradicado;

public class ConsultarRadicado {
	
	 private String radicado;

	 public String getRadicado() {
	 	return radicado;
	 }

	 public void setRadicado(String radicado) {
	 	this.radicado = radicado;
	 }

}
