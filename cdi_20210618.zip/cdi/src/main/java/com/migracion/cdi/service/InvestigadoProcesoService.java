package com.migracion.cdi.service;

public class InvestigadoProcesoService {

}
