package com.migracion.cdi.model;

import java.io.Serializable;

public class InvestigadoProcesoPK implements Serializable{
	private static final long serialVersionUID = 1L;
	
	protected Integer idProcesoDisciplinar;
	protected Integer idInvestigado;
	
	
	public InvestigadoProcesoPK() {}


	public InvestigadoProcesoPK(Integer idProcesoDisciplinar, Integer idInvestigado) {
		this.idProcesoDisciplinar = idProcesoDisciplinar;
		this.idInvestigado = idInvestigado;
	}


	public Integer getIdProcesoDisciplinar() {
		return idProcesoDisciplinar;
	}


	public void setIdProcesoDisciplinar(Integer idProcesoDisciplinar) {
		this.idProcesoDisciplinar = idProcesoDisciplinar;
	}


	public Integer getIdInvestigado() {
		return idInvestigado;
	}


	public void setIdInvestigado(Integer idInvestigado) {
		this.idInvestigado = idInvestigado;
	}
	
	
	
	

}