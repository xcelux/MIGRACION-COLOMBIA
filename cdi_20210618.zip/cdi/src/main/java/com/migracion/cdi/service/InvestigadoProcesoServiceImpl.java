package com.migracion.cdi.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.migracion.cdi.dao.InvestigadoProcesoDao;
import com.migracion.cdi.model.InvestigadoProceso;

@Service
public class InvestigadoProcesoServiceImpl implements IInvestigadoProcesoService{
	
	@Autowired
	private InvestigadoProcesoDao investigadoProcesoDao;

	@Override
	public void guardar(InvestigadoProceso investigadoProceso) {
		investigadoProcesoDao.save(investigadoProceso);
		
	}

}
