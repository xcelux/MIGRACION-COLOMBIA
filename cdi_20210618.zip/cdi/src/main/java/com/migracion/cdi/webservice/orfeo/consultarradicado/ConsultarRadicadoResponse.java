package com.migracion.cdi.webservice.orfeo.consultarradicado;

public class ConsultarRadicadoResponse {
	
	String respuesta;

	public String getRespuesta() {
		return respuesta;
	}

	public void setRespuesta(String respuesta) {
		this.respuesta = respuesta;
	}

}
