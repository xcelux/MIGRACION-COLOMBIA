package com.migracion.cdi.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.migracion.cdi.common.MensajeLog;
import com.migracion.cdi.dao.TipoGeneralDao;
import com.migracion.cdi.model.TipoGeneral;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class TipoGeneralServiceImpl implements ITipoGeneralService{
	
	
	@Autowired
	private TipoGeneralDao tipoGeneralDao;
	
	@Override
	@Transactional(readOnly = true)
	public List<TipoGeneral> buscarTiposGeneralesPorValor(String valor) throws Exception {
		try {
		return tipoGeneralDao.buscarTiposGeneralesPorValor(valor);
		} catch (Exception e) {
			//log.error(MensajeLog.MENSAJE_ERROR_LOG,e);
			String mensajeError =String.format(MensajeLog.MENSAJE_FALLIDO_CONSULTAR_TODO);		
			throw new Exception(mensajeError,e);		 
		}
	}

	@Override
	public TipoGeneral buscarTipoGeneralesPorValor(String valor) throws Exception {
		try {
			return (TipoGeneral) tipoGeneralDao.buscarTipoGeneralPorValor(valor);
			} catch (Exception e) {
				//log.error(MensajeLog.MENSAJE_ERROR_LOG,e);
				String mensajeError =String.format(MensajeLog.MENSAJE_FALLIDO_CONSULTAR_TODO);		
				throw new Exception(mensajeError,e);		 
			}
	}

	@Override
	public List<TipoGeneral> buscarTiposGeneralesPorIdPadre(Integer idPadre) throws Exception {
		try {
			return tipoGeneralDao.buscarTiposGeneralesPorIdPadre(idPadre);
			} catch (Exception e) {
				//log.error(MensajeLog.MENSAJE_ERROR_LOG,e);
				String mensajeError =String.format(MensajeLog.MENSAJE_FALLIDO_CONSULTAR_TODO);		
				throw new Exception(mensajeError,e);		 
			}
	}
	
	
}
