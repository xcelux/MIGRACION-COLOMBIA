package com.migracion.cdi.service;


import com.migracion.cdi.model.ProcesoDisciplinar;

public interface IProcesoDisciplinarService {
	
	public void guardar(ProcesoDisciplinar procesoDisciplinar);
	public ProcesoDisciplinar consultaProcesoDisciplinarPorId(Integer id) throws Exception;
	public String buscarUltimoCodigoExpediente() throws Exception;
	public Integer buscarUltimoProcesoDisciplinar()throws Exception;
}
