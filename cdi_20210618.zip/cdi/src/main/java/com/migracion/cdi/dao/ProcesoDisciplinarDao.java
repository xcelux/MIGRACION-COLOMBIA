package com.migracion.cdi.dao;


import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.migracion.cdi.model.ProcesoDisciplinar;

@Repository
public interface ProcesoDisciplinarDao extends CrudRepository<ProcesoDisciplinar, Integer> {
	
	@Query("SELECT p FROM ProcesoDisciplinar p WHERE p.idProcesoDisciplinar = :id")
	public ProcesoDisciplinar consultaProcesoDisciplinarPorId(Integer id);
	
	@Query(value = " SELECT  numeroexpediente FROM procesodisciplinar WHERE fechaelaboracionformato = (SELECT max(fechaelaboracionformato) FROM procesodisciplinar)", nativeQuery = true)
	public String buscarUltimoCodigoExpediente();
	
	@Query(value = " SELECT  max(idProcesoDisciplinar) FROM procesodisciplinar ", nativeQuery = true)
	public Integer buscarUltimoProcesoDisciplinar();

}
