package com.migracion.cdi.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.migracion.cdi.model.InvestigadoProceso;
import com.migracion.cdi.model.InvestigadoProcesoPK;

@Repository
public interface InvestigadoProcesoDao extends CrudRepository<InvestigadoProceso, InvestigadoProcesoPK>{

}
