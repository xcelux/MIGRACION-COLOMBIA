package com.migracion.cdi.service;

import java.util.List;

import com.migracion.cdi.model.Subtipologia;

public interface ISubtipologiaService {
	
	public List<Subtipologia> consultaListaSubtipologias() throws Exception;
	
	public List<Subtipologia> buscarSubtipologiasPorIdTipologia(Integer idTipologia) throws Exception;

}