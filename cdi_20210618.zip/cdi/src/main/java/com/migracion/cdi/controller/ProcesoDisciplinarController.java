package com.migracion.cdi.controller;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.migracion.cdi.common.CDIUtil;
import com.migracion.cdi.model.InvestigadoProceso;
import com.migracion.cdi.model.ProcesoDisciplinar;
import com.migracion.cdi.model.Subtipologia;
import com.migracion.cdi.model.TipoGeneral;
import com.migracion.cdi.model.Tipologia;
import com.migracion.cdi.service.IInvestigadoProcesoService;
import com.migracion.cdi.service.IProcesoDisciplinarService;
import com.migracion.cdi.service.ISubtipologiaService;
import com.migracion.cdi.service.ITipoGeneralService;
import com.migracion.cdi.service.ITipologiaService;



@Controller
@RequestMapping(value="/proceso")
public class ProcesoDisciplinarController {	
	
	@Autowired
	private IProcesoDisciplinarService procesoDisciplinarService;
	
	@Autowired
	private ITipoGeneralService tipoGeneralService;
	
	@Autowired
	private ITipologiaService tipologiaService;
	
	@Autowired
	private ISubtipologiaService subtipologiaService;
	
	@Autowired
	private IInvestigadoProcesoService iInvestigadoProcesoService;
	
	private CDIUtil cdiUtil = new CDIUtil();
	
	List<InvestigadoProceso> listaFuncionariosSelect;
	
	
	@GetMapping("/crear")
	public String mostrarHome(Model model) {
		
		List<TipoGeneral> nacionalidadesSelect = new LinkedList<TipoGeneral>();
		List<TipoGeneral> regionalesSelect = new LinkedList<TipoGeneral>();
		List<TipoGeneral> fuenteDatosSelect = new LinkedList<TipoGeneral>();
		List<TipoGeneral> tipoProcesoSelect = new LinkedList<TipoGeneral>();
		List<TipoGeneral> tipoQuejosoSelect = new LinkedList<TipoGeneral>();
		List<Tipologia> tipologiaSelect = new LinkedList<Tipologia>();
		List<Subtipologia> subtipologiaSelect = new LinkedList<Subtipologia>();
		listaFuncionariosSelect = new LinkedList<InvestigadoProceso>();
		
		ProcesoDisciplinar procesoDisciplinar = new ProcesoDisciplinar();
				
		try {
			
			nacionalidadesSelect = tipoGeneralService.buscarTiposGeneralesPorValor("Nacionalidad");
			regionalesSelect     = tipoGeneralService.buscarTiposGeneralesPorValor("Regional");
			fuenteDatosSelect    = tipoGeneralService.buscarTiposGeneralesPorValor("FuenteDatos");
			tipoProcesoSelect    = tipoGeneralService.buscarTiposGeneralesPorValor("TipoProceso");
			tipoQuejosoSelect    = tipoGeneralService.buscarTiposGeneralesPorValor("TipoQuejoso");
			tipologiaSelect      = tipologiaService.consultaListaTipologias();
			subtipologiaSelect   = subtipologiaService.consultaListaSubtipologias();
			
			InvestigadoProceso investigadoProceso = new InvestigadoProceso();
			investigadoProceso.setIdInvestigado(1);
			investigadoProceso.setNombreInvestigado("ALEXANDER TRES PALACIOS");
			listaFuncionariosSelect.add(investigadoProceso);
			
			InvestigadoProceso investigadoProceso2 = new InvestigadoProceso();
			investigadoProceso2.setIdInvestigado(2);
			investigadoProceso2.setNombreInvestigado("ANDRÉS VILLA NUEVA");
			listaFuncionariosSelect.add(investigadoProceso2);
			
			InvestigadoProceso investigadoProceso3 = new InvestigadoProceso();
			investigadoProceso3.setIdInvestigado(3);
			investigadoProceso3.setNombreInvestigado("FELIPE SANTODOMINGO");
			listaFuncionariosSelect.add(investigadoProceso3);
			
			InvestigadoProceso investigadoProceso4 = new InvestigadoProceso();
			investigadoProceso4.setIdInvestigado(4);
			investigadoProceso4.setNombreInvestigado("PABLO LACOTURIE");
			listaFuncionariosSelect.add(investigadoProceso4);
			
			if(listaFuncionariosSelect.get(0).getIdInvestigado()==1) {
				String nombreInvestigado = listaFuncionariosSelect.get(0).getNombreInvestigado();
			}
			
			//linea de codigo creada exclusivamente para probar relacion entre tablas
			procesoDisciplinar = procesoDisciplinarService.consultaProcesoDisciplinarPorId(7);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		model.addAttribute("nacionalidadesSelect",nacionalidadesSelect);
		model.addAttribute("regionalesSelect",regionalesSelect);
		model.addAttribute("fuenteDatosSelect",fuenteDatosSelect);
		model.addAttribute("tipoProcesoSelect",tipoProcesoSelect);
		model.addAttribute("tipoQuejosoSelect",tipoQuejosoSelect);
		model.addAttribute("tipologiaSelect",tipologiaSelect);
		model.addAttribute("subtipologiaSelect",subtipologiaSelect);
		model.addAttribute("listaFuncionariosSelect",listaFuncionariosSelect);
		
		return "proceso/proceso";
	}
	
	
	@RequestMapping(value="/guardar", method = RequestMethod.POST)
	public String guardar(ProcesoDisciplinar procesoDisciplinar, BindingResult result, RedirectAttributes attributes, @RequestParam("investigados") Integer[] investigados) {
		
		if(result.hasErrors()) {
			for(ObjectError error: result.getAllErrors()) {
				System.out.println("Ocurrio un error: "+error.getDefaultMessage());
			}
			
			return "redirect:/proceso/crear";
		}
		
		
		try {
			
			String ultimoCodigoExpediente = procesoDisciplinarService.buscarUltimoCodigoExpediente();
			if(ultimoCodigoExpediente==null) {
				procesoDisciplinar.setNumeroExpediente("0001/"+cdiUtil.anioActual());
			}else {
				procesoDisciplinar.setNumeroExpediente(cdiUtil.generarCodidgoExpediente(ultimoCodigoExpediente));
			}
			
			TipoGeneral estadoDecision = new TipoGeneral();
			estadoDecision = tipoGeneralService.buscarTipoGeneralesPorValor("Evaluacion");
			
			TipoGeneral etapa = new TipoGeneral();
			etapa = tipoGeneralService.buscarTipoGeneralesPorValor("Evaluar Noticia");
			
			procesoDisciplinar.setEstado(1);
			procesoDisciplinar.setFechaElaboracionFormato(new Date());
			procesoDisciplinar.setIdRadicadoOrfeo("6251-1");
			procesoDisciplinar.setIdEstadoDecision(estadoDecision);
			procesoDisciplinar.setIdEtapaActual(etapa);
			
			procesoDisciplinarService.guardar(procesoDisciplinar);
			
			int idProcesoDisciplinar = procesoDisciplinarService.buscarUltimoProcesoDisciplinar();
			
			List<InvestigadoProceso> listaInvestigados = cdiUtil.obtenerListaInvestigadosPorId(listaFuncionariosSelect, investigados, idProcesoDisciplinar);
			
			for(int i=0;i<listaInvestigados.size();i++) {
				iInvestigadoProcesoService.guardar(listaInvestigados.get(i));
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		attributes.addFlashAttribute("msg","Proceso Guardado Satisfactoriamente. --> Radicado Orfeo "+procesoDisciplinar.getIdRadicadoOrfeo());
		return "redirect:/proceso/crear";
		
	}
	
	
	@ResponseBody
	@GetMapping("/dependencias/{idRegional}")
	public List<TipoGeneral> buscarDependencias(@PathVariable("idRegional") Integer idRegional) throws Exception {
		List<TipoGeneral> dependenciasSelect = new LinkedList<TipoGeneral>();
		dependenciasSelect = tipoGeneralService.buscarTiposGeneralesPorIdPadre(idRegional);
		return dependenciasSelect;
	}
	
	@ResponseBody
	@GetMapping("/subtipologias/{idTipologia}")
	public List<Subtipologia> buscarSubtipologias(@PathVariable("idTipologia") Integer idTipologia) throws Exception {
		List<Subtipologia> subtipologiasSelect = new LinkedList<Subtipologia>();
		subtipologiasSelect = subtipologiaService.buscarSubtipologiasPorIdTipologia(idTipologia);
		return subtipologiasSelect;
	}
	
	
	@InitBinder
	public void initBinder(WebDataBinder webDataBinder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		dateFormat.setLenient(false);
		webDataBinder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat,true));
	}
	

}
